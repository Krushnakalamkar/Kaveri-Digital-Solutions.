import { cache } from "react";
import { getAdmin, requireAdmin } from "./auth";
import { prisma } from "./db";

type AdminOptions = { admin?: boolean } | boolean;
function adminMode(options?: AdminOptions) {
  return options === true || (typeof options === "object" && options?.admin === true);
}

export const getProfile = cache(async () => {
  const [profile, socialLinks] = await Promise.all([
    prisma.profile.findUniqueOrThrow({ where: { id: "singleton" } }),
    prisma.socialLink.findMany({ where: { active: true }, orderBy: { order: "asc" } }),
  ]);
  return {
    ...profile,
    about: profile.biography,
    bio: profile.biography,
    title: profile.professionalTitle,
    role: profile.professionalTitle,
    socialLinks,
  };
});

export async function getServices(options?: AdminOptions) {
  const all = adminMode(options);
  if (all) await requireAdmin();
  return prisma.service.findMany({
    where: all ? {} : { active: true, category: { active: true } },
    include: { category: true },
    orderBy: [{ category: { order: "asc" } }, { order: "asc" }],
  });
}

export async function getServiceCategories(options?: AdminOptions) {
  const all = adminMode(options);
  if (all) await requireAdmin();
  return prisma.serviceCategory.findMany({
    where: all ? {} : { active: true },
    include: {
      services: {
        where: all ? {} : { active: true },
        orderBy: { order: "asc" },
      },
    },
    orderBy: { order: "asc" },
  });
}

export async function getServiceBySlug(slug: string) {
  const category = await prisma.serviceCategory.findFirst({
    where: { slug, active: true },
    include: { services: { where: { active: true }, orderBy: { order: "asc" } } },
  });
  if (category) return category;
  return prisma.service.findFirst({
    where: { slug, active: true, category: { active: true } },
    include: { category: true },
  });
}

export async function getProjects(options?: AdminOptions) {
  const all = adminMode(options);
  if (all) await requireAdmin();
  const projects = await prisma.project.findMany({
    where: all ? {} : { published: true },
    include: { images: { orderBy: { order: "asc" } } },
    orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
  });
  return projects.map(project => ({
    ...project, imageUrl: project.images[0]?.imageUrl, imageAlt: project.images[0]?.altText,
  }));
}

export async function getProjectBySlug(slug: string) {
  const project = await prisma.project.findUnique({
    where: { slug },
    include: { images: { orderBy: { order: "asc" } } },
  });
  if (project && !project.published && !(await getAdmin())) return null;
  return project ? { ...project, imageUrl: project.images[0]?.imageUrl, imageAlt: project.images[0]?.altText } : null;
}

export async function getProjectById(id: string) {
  await requireAdmin();
  return prisma.project.findUnique({
    where: { id },
    include: { images: { orderBy: { order: "asc" } } },
  });
}

export async function getSkills(options?: AdminOptions) {
  const all = adminMode(options);
  if (all) await requireAdmin();
  return prisma.skill.findMany({
    where: all ? {} : { active: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
  });
}

export const getResume = cache(async () =>
  prisma.resume.findFirst({ where: { active: true }, orderBy: { createdAt: "desc" } }),
);

export const getSettings = cache(async () => {
  const [settings, profile, socialLinks] = await Promise.all([
    prisma.siteSettings.findUniqueOrThrow({ where: { id: "singleton" } }),
    getProfile(),
    prisma.socialLink.findMany({ where: { active: true } }),
  ]);
  return {
    ...settings,
    siteDescription: settings.description,
    businessEmail: profile.businessEmail,
    phone: profile.phone,
    instagramUrl: socialLinks.find(link => link.platform === "instagram")?.url ?? "",
    linkedinUrl: socialLinks.find(link => link.platform === "linkedin")?.url ?? "",
  };
});

export async function getMessages() {
  await requireAdmin();
  return prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
}

export async function getMessageById(id: string) {
  await requireAdmin();
  return prisma.contactMessage.findUnique({ where: { id } });
}

export async function getDashboardSummary() {
  await requireAdmin();
  const [projects, publishedProjects, featuredProjects, messages, newMessages, services, skills, recentMessages] =
    await Promise.all([
      prisma.project.count(),
      prisma.project.count({ where: { published: true } }),
      prisma.project.count({ where: { featured: true } }),
      prisma.contactMessage.count(),
      prisma.contactMessage.count({ where: { status: "New" } }),
      prisma.service.count({ where: { active: true } }),
      prisma.skill.count({ where: { active: true } }),
      prisma.contactMessage.findMany({ orderBy: { createdAt: "desc" }, take: 5 }),
    ]);
  return {
    totalProjects: projects, publishedProjects, featuredProjects,
    totalMessages: messages, newMessages, totalServices: services,
    totalSkills: skills, recentMessages,
  };
}