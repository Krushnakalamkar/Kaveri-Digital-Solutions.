import { randomUUID } from "node:crypto";
import { Readable } from "node:stream";
import { Storage } from "@google-cloud/storage";
import { z } from "zod";
import { prisma } from "./db";
import { equalSecrets, secretHash } from "./security";

const SIDECAR = "http://127.0.0.1:1106";
const storage = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${SIDECAR}/token`,
    type: "external_account",
    credential_source: {
      url: `${SIDECAR}/credential`,
      format: { type: "json", subject_token_field_name: "access_token" },
    },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export const uploadSchema = z.object({
  name: z.string().trim().min(1).max(180),
  size: z.number().int().min(1).max(10 * 1024 * 1024),
  contentType: z.enum(["image/jpeg", "image/png", "image/webp", "application/pdf"]),
  kind: z.enum(["image", "resume", "attachment"]),
});

function objectLocation() {
  const pieces = (process.env.PRIVATE_OBJECT_DIR ?? "").split("/").filter(Boolean);
  if (pieces.length < 2) throw new Error("Storage is not configured.");
  return { bucket: pieces[0]!, prefix: pieces.slice(1).join("/") };
}

export function mediaFile(key: string) {
  return storage.bucket(objectLocation().bucket).file(key);
}

export async function requestUpload(input: z.infer<typeof uploadSchema>, adminId?: string) {
  const { kind, contentType, size, name } = input;
  const extension = name.split(".").pop()?.toLowerCase();
  const extensions: Record<string, string[]> = {
    "image/jpeg": ["jpg", "jpeg"],
    "image/png": ["png"],
    "image/webp": ["webp"],
    "application/pdf": ["pdf"],
  };
  if (!extension || !extensions[contentType]?.includes(extension) ||
    (kind === "image" && (!contentType.startsWith("image/") || size > 5 * 1024 * 1024)) ||
    (kind === "resume" && contentType !== "application/pdf")) {
    throw new Error("Use a supported image or PDF within the size limit.");
  }
  const id = randomUUID();
  const location = objectLocation();
  const objectKey = `${location.prefix}/portfolio/${id}`;
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  const response = await fetch(`${SIDECAR}/object-storage/signed-object-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      bucket_name: location.bucket, object_name: objectKey, method: "PUT",
      expires_at: expiresAt.toISOString(),
    }),
    signal: AbortSignal.timeout(10000),
  });
  if (!response.ok) throw new Error("A secure upload URL could not be created.");
  const result = await response.json() as { signed_url: string };
  await prisma.mediaUpload.create({
    data: { id, objectKey, originalName: name, mimeType: contentType, size, kind, adminId, expiresAt },
  });
  return {
    uploadURL: result.signed_url,
    uploadId: id,
    token: secretHash(`upload:${id}:${size}:${contentType}`),
    objectPath: `/portfolio-api/media/${id}`,
  };
}

function validSignature(buffer: Buffer, mime: string) {
  if (mime === "application/pdf") return buffer.subarray(0, 5).toString() === "%PDF-";
  if (mime === "image/png") return buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if (mime === "image/jpeg") return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  if (mime === "image/webp") return buffer.subarray(0, 4).toString() === "RIFF" && buffer.subarray(8, 12).toString() === "WEBP";
  return false;
}

export async function finalizeUpload(id: string, token: string, adminId?: string) {
  const ticket = await prisma.mediaUpload.findUnique({ where: { id } });
  if (!ticket || ticket.expiresAt < new Date() ||
    !equalSecrets(token, secretHash(`upload:${id}:${ticket.size}:${ticket.mimeType}`)) ||
    (ticket.kind !== "attachment" && ticket.adminId !== adminId)) {
    throw new Error("The upload has expired or could not be verified.");
  }
  const file = mediaFile(ticket.objectKey);
  const [metadata] = await file.getMetadata();
  const [head] = await file.download({ start: 0, end: 15 });
  if (Number(metadata.size) !== ticket.size || metadata.contentType !== ticket.mimeType ||
    !validSignature(head, ticket.mimeType)) {
    await file.delete({ ignoreNotFound: true });
    await prisma.mediaUpload.delete({ where: { id } });
    throw new Error("The uploaded file did not match its declared type or size.");
  }
  await prisma.mediaUpload.update({ where: { id }, data: { finalized: true } });
  return {
    fileUrl: `/portfolio-api/media/${id}`,
    fileName: ticket.originalName,
    mimeType: ticket.mimeType,
    fileSize: ticket.size,
  };
}

export async function streamMedia(key: string, mime: string, size: number, name: string, download: boolean, isPublic: boolean) {
  const stream = Readable.toWeb(mediaFile(key).createReadStream()) as ReadableStream<Uint8Array>;
  const filename = name.replace(/[^a-zA-Z0-9._ -]/g, "_");
  return new Response(stream, {
    headers: {
      "Content-Type": mime,
      "Content-Length": String(size),
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${filename}"`,
      "Cache-Control": isPublic ? "public, max-age=86400" : "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'; sandbox",
    },
  });
}