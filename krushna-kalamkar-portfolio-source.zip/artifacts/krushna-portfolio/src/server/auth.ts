import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "./db";
import { tokenHash } from "./security";
import { isConfiguredOwner } from "./owner-access";

const COOKIE = "krushna_admin_session";
const SESSION_SECONDS = 60 * 60 * 12;

export async function getAdmin() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const session = await prisma.adminSession.findUnique({
    where: { tokenHash: tokenHash(token) },
    include: { admin: { select: { id: true, email: true } } },
  });
  if (!session || session.expiresAt <= new Date()) return null;
  return session.admin;
}

export async function requireAdmin() {
  const admin = await getAdmin();
  if (!admin) redirect("/admin/login");
  return admin;
}

export async function requireOwnerAdmin() {
  const admin = await getAdmin();
  if (!admin) redirect("/admin/login");
  if (!isConfiguredOwner(admin)) redirect("/admin/dashboard");
  return admin;
}

export async function createSession(adminId: string) {
  const token = randomBytes(32).toString("hex");
  await prisma.adminSession.create({
    data: {
      adminId,
      tokenHash: tokenHash(token),
      expiresAt: new Date(Date.now() + SESSION_SECONDS * 1000),
    },
  });
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_SECONDS,
  });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) {
    await prisma.adminSession.deleteMany({ where: { tokenHash: tokenHash(token) } });
  }
  jar.delete(COOKIE);
}