"use server";

import bcrypt from "bcryptjs";
import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "./db";
import { createSession, destroySession, requireAdmin } from "./auth";
import { clientIdentifier, consumeLimit, equalSecrets } from "./security";

const slugSchema = z.string().min(1).max(160).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);
const emailSchema = z.string().trim().email().max(254);
const safeUrlSchema = z.string().url().max(2048).refine(value => /^https?:\/\//i.test(value));
const idSchema = z.string().min(1).max(100);

function text(form: FormData, name: string, fallback = "") {
  const value = form.get(name);
  return typeof value === "string" ? value.trim() : fallback;
}

function checked(form: FormData, name: string) {
  return ["on", "true", "1"].includes(text(form, name));
}

function slug(value: string) {
  return value.toLowerCase().normalize("NFKD").replace(/[^\w\s-]/g, "")
    .trim().replace(/[\s_-]+/g, "-");
}

function optionalUrl(value: string) {
  return value ? safeUrlSchema.parse(value) : null;
}

function bounded(value: string, maximum = 10000) {
  return z.string().max(maximum).parse(value);
}

async function mutation(path: string, operation: () => Promise<unknown>) {
  await requireAdmin();
  let errorMessage: string | null = null;
  try {
    await operation();
  } catch (error) {
    if (error instanceof z.ZodError) {
      errorMessage = "Please check the required fields, URLs, and maximum lengths.";
    } else if (error instanceof InputError) {
      errorMessage = error.message;
    } else if ((error as { code?: string }).code === "P2002") {
      errorMessage = "That name or URL slug is already in use.";
    } else {
      console.error("Admin update failed.");
      errorMessage = "Changes could not be saved. Please try again.";
    }
  }
  if (errorMessage) redirect(`${path}?error=${encodeURIComponent(errorMessage)}`);
  revalidatePath("/", "layout");
  redirect(`${path}?saved=1`);
}

class InputError extends Error {}

async function verifiedMedia(url: string, kind: "image" | "resume") {
  const match = /^\/portfolio-api\/media\/([a-f0-9-]{36})$/.exec(url);
  if (!match) throw new InputError("Please complete a secure file upload first.");
  const admin = await requireAdmin();
  const media = await prisma.mediaUpload.findFirst({
    where: { id: match[1], finalized: true, kind, adminId: admin.id },
  });
  if (!media) throw new InputError("The uploaded file could not be verified.");
  return media;
}

export async function authenticateAdmin(form: FormData) {
  let adminId: string | null = null;
  try {
    const email = emailSchema.parse(text(form, "email").toLowerCase());
    const password = z.string().min(1).max(256).parse(form.get("password"));
    const identity = await clientIdentifier();
    const allowed = await consumeLimit(`login:${identity}`, 5, 900);
    if (!allowed) redirect("/admin/login?error=rate-limit");
    let admin = await prisma.adminUser.findUnique({ where: { email } });
    if (!admin && (await prisma.adminUser.count()) === 0) {
      const configuredEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
      const configuredPassword = process.env.ADMIN_PASSWORD;
      if (configuredEmail && configuredPassword &&
        equalSecrets(email, configuredEmail) && equalSecrets(password, configuredPassword)) {
        admin = await prisma.adminUser.create({
          data: { email, hashedPassword: await bcrypt.hash(password, 12) },
        });
      }
    }
    if (admin && await bcrypt.compare(password, admin.hashedPassword)) adminId = admin.id;
  } catch {
    // Login failures always use a generic response, including bootstrap failures.
  }
  if (!adminId) redirect("/admin/login?error=invalid");
  await createSession(adminId);
  redirect("/admin/dashboard");
}

export async function logoutAdmin() {
  await destroySession();
  redirect("/admin/login");
}

export async function saveProject(form: FormData) {
  await mutation("/admin/projects", async () => {
    const id = text(form, "id");
    const title = z.string().min(1).max(160).parse(text(form, "title"));
    const data = {
      title,
      slug: slugSchema.parse(text(form, "slug") || slug(title)),
      shortDescription: bounded(text(form, "shortDescription") || text(form, "summary"), 500),
      description: bounded(text(form, "description"), 30000),
      category: bounded(text(form, "category"), 120),
      technologies: text(form, "technologies").split(",").map(item => item.trim())
        .filter(Boolean).slice(0, 30).map(item => bounded(item, 60)),
      challenge: bounded(text(form, "challenge"), 10000),
      approach: bounded(text(form, "approach"), 10000),
      development: bounded(text(form, "development"), 10000),
      result: bounded(text(form, "result"), 10000),
      liveUrl: optionalUrl(text(form, "liveUrl")),
      githubUrl: optionalUrl(text(form, "githubUrl")),
      published: checked(form, "published"),
      featured: checked(form, "featured"),
    };
    let images: Array<{ imageUrl: string; altText: string }> | undefined;
    if (form.has("images")) {
      const parsed = JSON.parse(text(form, "images") || "[]");
      images = z.array(z.object({
        imageUrl: z.string().max(300),
        altText: z.string().trim().min(1).max(300),
      })).max(12).parse(parsed);
    } else if (text(form, "imageUrl")) {
      images = [{
        imageUrl: text(form, "imageUrl"),
        altText: z.string().min(1).max(300).parse(text(form, "altText") || text(form, "imageAlt")),
      }];
    }
    for (const image of images ?? []) await verifiedMedia(image.imageUrl, "image");
    await prisma.$transaction(async transaction => {
      const project = id
        ? await transaction.project.update({ where: { id: idSchema.parse(id) }, data })
        : await transaction.project.create({ data });
      if (images) {
        await transaction.projectImage.deleteMany({ where: { projectId: project.id } });
        if (images.length) await transaction.projectImage.createMany({
          data: images.map((image, order) => ({ ...image, order, projectId: project.id })),
        });
      }
    });
  });
}

export async function deleteProject(form: FormData) {
  await mutation("/admin/projects", () => prisma.project.delete({
    where: { id: idSchema.parse(text(form, "id")) },
  }));
}

export async function setProjectPublish(form: FormData) {
  await mutation("/admin/projects", () => prisma.project.update({
    where: { id: idSchema.parse(text(form, "id")) }, data: { published: checked(form, "published") },
  }));
}

export async function setProjectFeatured(form: FormData) {
  await mutation("/admin/projects", () => prisma.project.update({
    where: { id: idSchema.parse(text(form, "id")) }, data: { featured: checked(form, "featured") },
  }));
}

export async function saveCategory(form: FormData) {
  await mutation("/admin/services", async () => {
    const id = text(form, "id");
    const name = z.string().min(1).max(120).parse(text(form, "name"));
    const data = {
      name, slug: slugSchema.parse(text(form, "slug") || slug(name)),
      description: bounded(text(form, "description"), 2000),
      icon: bounded(text(form, "icon"), 40),
      active: id || form.has("activePresent") ? checked(form, "active") : true,
    };
    if (id) await prisma.serviceCategory.update({ where: { id }, data });
    else await prisma.serviceCategory.create({
      data: { ...data, order: await prisma.serviceCategory.count() },
    });
  });
}

export async function deleteCategory(form: FormData) {
  await mutation("/admin/services", () => prisma.serviceCategory.delete({
    where: { id: idSchema.parse(text(form, "id")) },
  }));
}

async function reorder(id: string, direction: string, kind: "category" | "service") {
  if (!["up", "down"].includes(direction)) throw new InputError("Choose a valid order change.");
  const service = kind === "service" ? await prisma.service.findUniqueOrThrow({ where: { id } }) : null;
  const rows = kind === "service"
    ? await prisma.service.findMany({ where: { categoryId: service!.categoryId }, orderBy: [{ order: "asc" }, { id: "asc" }] })
    : await prisma.serviceCategory.findMany({ orderBy: [{ order: "asc" }, { id: "asc" }] });
  const position = rows.findIndex(row => row.id === id);
  const target = position + (direction === "up" ? -1 : 1);
  if (position < 0 || target < 0 || target >= rows.length) return;
  [rows[position], rows[target]] = [rows[target]!, rows[position]!];
  await prisma.$transaction(rows.map((row, order) => kind === "service"
    ? prisma.service.update({ where: { id: row.id }, data: { order } })
    : prisma.serviceCategory.update({ where: { id: row.id }, data: { order } })));
}

export async function moveCategory(form: FormData) {
  await mutation("/admin/services", () => reorder(idSchema.parse(text(form, "id")), text(form, "direction"), "category"));
}

export async function moveService(form: FormData) {
  await mutation("/admin/services", () => reorder(idSchema.parse(text(form, "id")), text(form, "direction"), "service"));
}

export async function saveService(form: FormData) {
  await mutation("/admin/services", async () => {
    const id = text(form, "id");
    const name = z.string().min(1).max(150).parse(text(form, "name"));
    const categoryId = text(form, "categoryId") || (await prisma.serviceCategory.findFirst({
      where: { name: text(form, "category") },
    }))?.id;
    if (!categoryId) throw new InputError("Choose a service category.");
    const data = {
      name, categoryId, slug: slugSchema.parse(text(form, "slug") || slug(name)),
      description: bounded(text(form, "description"), 3000),
      details: bounded(text(form, "details"), 10000),
      active: id || form.has("activePresent") ? checked(form, "active") : true,
    };
    if (id) await prisma.service.update({ where: { id }, data });
    else await prisma.service.create({
      data: { ...data, order: await prisma.service.count({ where: { categoryId } }) },
    });
  });
}

export async function deleteService(form: FormData) {
  await mutation("/admin/services", () => prisma.service.delete({ where: { id: idSchema.parse(text(form, "id")) } }));
}

export async function toggleService(form: FormData) {
  await mutation("/admin/services", async () => {
    const service = await prisma.service.findUniqueOrThrow({ where: { id: idSchema.parse(text(form, "id")) } });
    await prisma.service.update({ where: { id: service.id }, data: { active: !service.active } });
  });
}

export async function setMessageStatus(form: FormData) {
  await mutation("/admin/messages", () => prisma.contactMessage.update({
    where: { id: idSchema.parse(text(form, "id")) },
    data: { status: z.enum(["New", "Read", "Replied", "Archived"]).parse(text(form, "status")) },
  }));
}

export async function deleteMessage(form: FormData) {
  await mutation("/admin/messages", () => prisma.contactMessage.delete({
    where: { id: idSchema.parse(text(form, "id")) },
  }));
}

export async function saveSkill(form: FormData) {
  await mutation("/admin/skills", async () => {
    const id = text(form, "id");
    const data = {
      name: z.string().min(1).max(100).parse(text(form, "name")),
      category: bounded(text(form, "category") || text(form, "group"), 100),
      order: z.coerce.number().int().min(0).max(10000).parse(text(form, "order") || "0"),
      active: id || form.has("activePresent") ? checked(form, "active") : true,
    };
    if (id) await prisma.skill.update({ where: { id }, data });
    else await prisma.skill.create({ data });
  });
}

export async function deleteSkill(form: FormData) {
  await mutation("/admin/skills", () => prisma.skill.delete({ where: { id: idSchema.parse(text(form, "id")) } }));
}

export async function saveProfile(form: FormData) {
  await mutation("/admin/profile", async () => {
    const photoUrl = text(form, "photoUrl");
    if (photoUrl && photoUrl !== "/images/krushna-kalamkar.png") await verifiedMedia(photoUrl, "image");
    await prisma.profile.update({
      where: { id: "singleton" },
      data: {
        name: z.string().min(1).max(120).parse(text(form, "name")),
        professionalTitle: bounded(text(form, "professionalTitle") || text(form, "role"), 160),
        tagline: bounded(text(form, "tagline"), 500),
        intro: bounded(text(form, "intro"), 2000),
        biography: bounded(text(form, "biography") || text(form, "about"), 10000),
        experience: bounded(text(form, "experience"), 100),
        location: bounded(text(form, "location"), 200),
        email: emailSchema.parse(text(form, "email")),
        ...(form.has("businessEmail") ? { businessEmail: emailSchema.parse(text(form, "businessEmail")) } : {}),
        ...(form.has("phone") ? { phone: bounded(text(form, "phone"), 40) } : {}),
        ...(form.has("photoUrl") ? { photoUrl: photoUrl || null } : {}),
      },
    });
  });
}

export async function saveSettings(form: FormData) {
  await mutation("/admin/settings", async () => {
    const settingsData = {
      siteTitle: z.string().min(1).max(200).parse(text(form, "siteTitle")),
      description: bounded(text(form, "description") || text(form, "siteDescription"), 500),
      canonicalUrl: optionalUrl(text(form, "canonicalUrl")),
    };
    const profileData = {
      businessEmail: emailSchema.parse(text(form, "businessEmail")),
      phone: bounded(text(form, "phone"), 40),
    };
    const socialData = ["instagram", "linkedin"].map(platform => ({
      platform, url: optionalUrl(text(form, `${platform}Url`)),
    }));
    await prisma.$transaction([
      prisma.siteSettings.update({
      where: { id: "singleton" },
      data: settingsData,
      }),
      prisma.profile.update({
      where: { id: "singleton" },
      data: profileData,
      }),
      ...socialData.map(({ platform, url }) => url ? prisma.socialLink.upsert({
        where: { platform },
        create: { platform, label: platform === "instagram" ? "Instagram" : "LinkedIn", url },
        update: { url, active: true },
      }) : prisma.socialLink.updateMany({ where: { platform }, data: { active: false } })),
    ]);
  });
}

export async function saveResume(form: FormData) {
  await mutation("/admin/resume", async () => {
    const fileUrl = text(form, "fileUrl");
    const upload = await verifiedMedia(fileUrl, "resume");
    await prisma.$transaction([
      prisma.resume.updateMany({ data: { active: false } }),
      prisma.resume.create({
        data: {
          fileUrl, fileName: upload.originalName, mimeType: upload.mimeType, fileSize: upload.size,
        },
      }),
    ]);
  });
}

export async function deleteResume(form: FormData) {
  await mutation("/admin/resume", () => prisma.resume.delete({
    where: { id: idSchema.parse(text(form, "id")) },
  }));
}