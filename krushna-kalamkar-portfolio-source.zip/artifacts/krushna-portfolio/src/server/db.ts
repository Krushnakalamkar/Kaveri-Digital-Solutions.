import { PrismaClient } from "@prisma/client";

const globalDatabase = globalThis as unknown as { portfolioPrisma?: PrismaClient };

export const prisma = globalDatabase.portfolioPrisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalDatabase.portfolioPrisma = prisma;
}