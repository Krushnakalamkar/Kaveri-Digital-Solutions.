type AdminIdentity = { email: string } | null | undefined;

export function isConfiguredOwner(admin: AdminIdentity, configuredEmail = process.env.ADMIN_EMAIL) {
  const ownerEmail = configuredEmail?.trim().toLowerCase();
  return Boolean(ownerEmail && admin?.email.trim().toLowerCase() === ownerEmail);
}
