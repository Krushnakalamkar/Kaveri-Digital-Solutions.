import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { headers } from "next/headers";
import { prisma } from "./db";

export function secretHash(value: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("Session configuration is unavailable.");
  return createHmac("sha256", secret).update(value).digest("hex");
}

export function tokenHash(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export function equalSecrets(left: string, right: string) {
  const a = Buffer.from(tokenHash(left));
  const b = Buffer.from(tokenHash(right));
  return timingSafeEqual(a, b);
}

export async function clientIdentifier() {
  const requestHeaders = await headers();
  const ip = requestHeaders.get("x-forwarded-for")?.split(",")[0]?.trim()
    ?? requestHeaders.get("x-real-ip")
    ?? "unknown";
  return secretHash(ip);
}

export async function consumeLimit(key: string, maximum: number, seconds: number) {
  const rows = await prisma.$queryRaw<Array<{ count: number }>>`
    INSERT INTO "RateLimitBucket" ("key", "count", "windowStart", "updatedAt")
    VALUES (${key}, 1, NOW(), NOW())
    ON CONFLICT ("key") DO UPDATE SET
      "count" = CASE
        WHEN "RateLimitBucket"."windowStart" < NOW() - (${seconds} * INTERVAL '1 second')
        THEN 1 ELSE "RateLimitBucket"."count" + 1 END,
      "windowStart" = CASE
        WHEN "RateLimitBucket"."windowStart" < NOW() - (${seconds} * INTERVAL '1 second')
        THEN NOW() ELSE "RateLimitBucket"."windowStart" END,
      "updatedAt" = NOW()
    RETURNING "count"
  `;
  return Boolean(rows[0] && rows[0].count <= maximum);
}

export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return false;
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}