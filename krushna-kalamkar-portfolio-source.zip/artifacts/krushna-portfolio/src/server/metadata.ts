import type { Metadata } from "next";
import { getSettings } from "./queries";

export async function siteBaseUrl() {
  const settings = await getSettings();
  const url = settings.canonicalUrl || process.env.SITE_URL;
  if (!url || !/^https?:\/\//.test(url)) return null;
  try { return new URL(url); } catch { return null; }
}

export async function pageMetadata(path: string, title: string, description?: string): Promise<Metadata> {
  const settings = await getSettings();
  const base = await siteBaseUrl();
  const summary = description || settings.description;
  const brandedTitle = title === settings.siteTitle ? title : `${title} | ${settings.siteTitle}`;
  const url = base ? new URL(path, base) : undefined;
  return {
    title, description: summary,
    ...(url ? { alternates: { canonical: url } } : {}),
    openGraph: { title: brandedTitle, siteName: settings.siteTitle, description: summary, type: "website", ...(url ? { url } : {}) },
    twitter: { card: "summary", title: brandedTitle, description: summary },
  };
}