import { ReplitConnectors, type ProxyOptions } from "@replit/connectors-sdk";
import { visitorIntakeRegions } from "@/lib/visitor-intake-regions";

const spreadsheetId = "1ln90QfuF8V0laWFUnfWcN1Mjpd-BXuYgVD6X7-xJNAg";
const sheetName = "Sheet1";
const valuesRange = encodeURIComponent(`'${sheetName}'!A:F`);

export { visitorIntakeRegions };

export type VisitorIntakeValues = [string, number, string, string, string, boolean];

async function sheetRequest(path: string, init: ProxyOptions = {}) {
  const connectors = new ReplitConnectors();
  return connectors.proxy("google-sheet", path, init);
}

function jsonRequest(method: string, body?: unknown): ProxyOptions {
  return {
    method,
    headers: { "Content-Type": "application/json" },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  };
}

export function visitorIntakeRowRange(rowNumber: number) {
  return encodeURIComponent(`'${sheetName}'!A${rowNumber}:F${rowNumber}`);
}

export async function appendVisitorIntake(values: VisitorIntakeValues) {
  return sheetRequest(
    `/v4/spreadsheets/${spreadsheetId}/values/${valuesRange}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    jsonRequest("POST", { majorDimension: "ROWS", values: [values] }),
  );
}

export async function readVisitorIntakeRows() {
  return sheetRequest(`/v4/spreadsheets/${spreadsheetId}/values/${valuesRange}`);
}

export async function replaceVisitorIntakeRow(rowNumber: number, values: VisitorIntakeValues) {
  const range = visitorIntakeRowRange(rowNumber);
  return sheetRequest(
    `/v4/spreadsheets/${spreadsheetId}/values/${range}?valueInputOption=RAW`,
    jsonRequest("PUT", { majorDimension: "ROWS", values: [values] }),
  );
}

export async function deleteVisitorIntakeRow(rowNumber: number) {
  const metadata = await sheetRequest(
    `/v4/spreadsheets/${spreadsheetId}?fields=sheets(properties(sheetId,title))`,
  );
  if (!metadata.ok) throw new Error("Visitor-intake sheet metadata could not be read.");

  const document = await metadata.json() as {
    sheets?: Array<{ properties?: { sheetId?: number; title?: string } }>;
  };
  const sheetId = document.sheets?.find(sheet => sheet.properties?.title === sheetName)?.properties?.sheetId;
  if (typeof sheetId !== "number") throw new Error("Visitor-intake sheet tab could not be found.");

  return sheetRequest(
    `/v4/spreadsheets/${spreadsheetId}:batchUpdate`,
    jsonRequest("POST", {
      requests: [{
        deleteDimension: {
          range: {
            sheetId,
            dimension: "ROWS",
            startIndex: rowNumber - 1,
            endIndex: rowNumber,
          },
        },
      }],
    }),
  );
}
