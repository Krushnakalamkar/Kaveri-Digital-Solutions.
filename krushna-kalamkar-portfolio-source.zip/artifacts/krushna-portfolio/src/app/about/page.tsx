import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';
import { getProfile } from '@/server/queries';
import { pageMetadata } from '@/server/metadata';

export const generateMetadata = () => pageMetadata('/about', 'About');
import { object, value } from '@/components/site/content';
import { PageHero, SiteShell } from '@/components/site/site-chrome';

const areas = [
  ['01', 'Technology', 'Web, software, apps & AI solutions.'],
  ['02', 'Creative', 'Design, video, content & social media.'],
  ['03', 'Digital Support', 'Data, documents, research & business support.'],
];

export default async function AboutPage() {
  const profile = object(await getProfile());
  return <SiteShell>
    <PageHero eyebrow={`ABOUT / ${value(profile, 'name').toUpperCase()}`} title={<>A little<br /><em>about me.</em></>} subtitle={`${value(profile, 'professionalTitle')} · ${value(profile, 'location')}`} />
    <section className="content-section about-page-copy">
      <p className="eyebrow burgundy">{value(profile, 'professionalTitle')}</p>
      <h2 className="display section-heading">Hello, I’m<br /><em>{value(profile, 'name')}.</em></h2>
      <p className="about-copy">{value(profile, 'about', 'biography')}</p>
      <div className="editorial-grid">{areas.map(([number, title, text]) => <article className="editorial-item" key={number}><span>{number}</span><h2>{title}</h2><p>{text}</p></article>)}</div>
      <div className="about-cta"><p className="eyebrow">Have an idea to move forward?</p><Link href="/contact" className="dark-text-link">Start a conversation <ArrowUpRight size={16} /></Link></div>
    </section>
  </SiteShell>;
}