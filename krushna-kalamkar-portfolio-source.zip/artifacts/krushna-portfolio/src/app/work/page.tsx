import { getProjects } from '@/server/queries';
import { pageMetadata } from '@/server/metadata';

export const generateMetadata = () => pageMetadata('/work', 'Selected Work');
import { list, ProjectCards, value } from '@/components/site/content';
import { PageHero, SiteShell } from '@/components/site/site-chrome';

export default async function WorkPage() {
  const projectData = await getProjects();
  const published = list(projectData).filter(project => project.published === true || project.isPublished === true || value(project, 'status').toLowerCase() === 'published');
  return <SiteShell>
    <PageHero eyebrow="WORK / SELECTED PROJECTS" title={<>Selected<br /><em>Work.</em></>} subtitle="A selection of digital experiences and solutions." />
    <section className="content-section">
      <ProjectCards data={published} />
    </section>
  </SiteShell>;
}