import { notFound } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowLeft, ArrowUpRight, Github } from 'lucide-react';
import { getProjectBySlug } from '@/server/queries';
import { CaseStudyFramework, object, techOf, value } from '@/components/site/content';
import { PageHero, SiteShell } from '@/components/site/site-chrome';
import { pageMetadata } from '@/server/metadata';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = await getProjectBySlug(slug);
  return { ...(await pageMetadata(`/work/${slug}`, project?.title ?? 'Project', project?.shortDescription)), ...(!project?.published ? { robots: { index: false, follow: false } } : {}) };
}

export default async function ProjectDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = object(await getProjectBySlug(slug));
  const published = project.published === true || project.isPublished === true || value(project, 'status').toLowerCase() === 'published';
  const title = value(project, 'title', 'name');
  if (!title) notFound();
  return <SiteShell>
    <PageHero eyebrow={`SELECTED WORK / ${value(project, 'category', 'type')}`} title={<>{title}<em>.</em></>} subtitle={value(project, 'summary', 'shortDescription', 'description')} />
    <section className="content-section">
      {!published ? <p className="admin-alert">Draft preview — only visible to a signed-in administrator.</p> : null}
      <Link href="/work" className="dark-text-link"><ArrowLeft size={15} /> Selected work</Link>
      {value(project, 'imageUrl') ? <div className="project-hero-image"><Image src={value(project, 'imageUrl')} alt={value(project, 'imageAlt') || `${title} project image`} fill priority unoptimized={!published} sizes="(max-width: 1200px) 100vw, 1200px" /></div> : null}
      {techOf(project).length ? <div className="tech-list">{techOf(project).map(t => <span key={t}>{t}</span>)}</div> : null}
      <div className="admin-inline-actions" style={{ marginTop: 14 }}>
        {value(project, 'liveUrl') ? <a className="dark-text-link" href={value(project, 'liveUrl')} target="_blank" rel="noreferrer">Visit live project <ArrowUpRight size={15} strokeWidth={1.75} aria-hidden="true" /></a> : null}
        {value(project, 'githubUrl') ? <a className="dark-text-link" href={value(project, 'githubUrl')} target="_blank" rel="noreferrer"><Github size={15} strokeWidth={1.75} aria-hidden="true" /> Source on GitHub</a> : null}
      </div>
      {value(project, 'description') ? <p className="project-detail-copy">{value(project, 'description')}</p> : null}
      <h2 className="display section-heading framework-heading">From Idea <em>→</em><br />Digital Product</h2>
      <CaseStudyFramework project={project} />
      {Array.isArray(project.images) ? project.images.slice(1).map((image, index) => {
        const item = object(image);
        // Private previews must use the browser's session; the optimizer does not forward it.
        return <div className="project-hero-image" key={index}><Image src={value(item, 'imageUrl')} alt={value(item, 'altText')} fill unoptimized={!published} sizes="(max-width: 1200px) 100vw, 1200px" /></div>;
      }) : null}
    </section>
  </SiteShell>;
}