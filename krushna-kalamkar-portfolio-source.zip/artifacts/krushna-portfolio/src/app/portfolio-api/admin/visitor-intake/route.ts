import { z } from "zod";
import { getAdmin } from "@/server/auth";
import { isConfiguredOwner } from "@/server/owner-access";
import { equalSecrets, sameOrigin, secretHash } from "@/server/security";
import {
  deleteVisitorIntakeRow,
  readVisitorIntakeRows,
  replaceVisitorIntakeRow,
  type VisitorIntakeValues,
} from "@/server/visitor-intake-sheet";
import { visitorIntakeRegions } from "@/lib/visitor-intake-regions";

export const dynamic = "force-dynamic";

const searchSchema = z.object({
  action: z.literal("search"),
  name: z.string().trim().min(2).max(100),
});
const tokenSchema = z.string().regex(/^[1-9]\d*\.[a-f0-9]{64}$/);
const inspectSchema = z.object({ action: z.literal("inspect"), token: tokenSchema });
const correctSchema = z.object({
  action: z.literal("correct"),
  token: tokenSchema,
  name: z.string().trim().min(2).max(100),
  age: z.number().int().min(1).max(120),
  state: z.enum(visitorIntakeRegions),
});
const deleteSchema = z.object({ action: z.literal("delete"), token: tokenSchema });
const actionSchema = z.discriminatedUnion("action", [
  searchSchema,
  inspectSchema,
  correctSchema,
  deleteSchema,
]);

type SheetRow = [string, number, string, string, string, boolean];

function normalizeRow(value: unknown): SheetRow {
  const cells = Array.isArray(value) ? value : [];
  return [
    String(cells[0] ?? ""),
    Number(cells[1] ?? ""),
    String(cells[2] ?? ""),
    String(cells[3] ?? ""),
    String(cells[4] ?? ""),
    cells[5] === true || String(cells[5] ?? "").toLowerCase() === "true",
  ];
}

function signedToken(rowNumber: number, row: SheetRow) {
  const signature = secretHash(`visitor-intake:${rowNumber}:${JSON.stringify(row)}`);
  return `${rowNumber}.${signature}`;
}

async function currentRow(token: string) {
  const [rowNumberText, signature] = token.split(".");
  const rowNumber = Number(rowNumberText);
  const response = await readVisitorIntakeRows();
  if (!response.ok) throw new Error("Visitor-intake entries could not be read.");
  const document = await response.json() as { values?: unknown[] };
  const rawRow = document.values?.[rowNumber - 1];
  if (!rawRow) return null;
  const row = normalizeRow(rawRow);
  const expected = signedToken(rowNumber, row).split(".")[1]!;
  if (!equalSecrets(signature!, expected)) return null;
  return { rowNumber, row };
}

function reply(body: unknown, status = 200) {
  return Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store, private" },
  });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return reply({ error: "This request could not be verified. Refresh and try again." }, 403);
  const admin = await getAdmin();
  if (!admin) return reply({ error: "Sign in to manage visitor requests." }, 401);
  if (!isConfiguredOwner(admin)) return reply({ error: "You do not have permission to manage visitor requests." }, 403);

  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 8_000) return reply({ error: "Please check the request and try again." }, 413);

  let input: z.infer<typeof actionSchema>;
  try {
    input = actionSchema.parse(await request.json());
  } catch {
    return reply({ error: "Check the request details and try again." }, 400);
  }

  try {
    if (input.action === "search") {
      const response = await readVisitorIntakeRows();
      if (!response.ok) return reply({ error: "Visitor-intake entries could not be read right now." }, 502);
      const document = await response.json() as { values?: unknown[] };
      const name = input.name.toLocaleLowerCase();
      const matches = (document.values ?? []).flatMap((value, index) => {
        const row = normalizeRow(value);
        if (!row[0] || row[0].trim().toLocaleLowerCase() !== name) return [];
        return [{
          token: signedToken(index + 1, row),
          name: row[0],
          state: row[2],
          date: row[3],
          time: row[4],
        }];
      });
      return reply({ matches });
    }

    const selected = await currentRow(input.token);
    if (!selected) return reply({ error: "That entry has changed since it was reviewed. Search again before making a change." }, 409);

    if (input.action === "inspect") {
      const [name, age, state, date, time] = selected.row;
      return reply({ entry: { name, age, state, date, time } });
    }

    if (input.action === "correct") {
      const values: VisitorIntakeValues = [
        input.name,
        input.age,
        input.state,
        selected.row[3],
        selected.row[4],
        selected.row[5],
      ];
      const response = await replaceVisitorIntakeRow(selected.rowNumber, values);
      if (!response.ok) return reply({ error: "The correction could not be saved. No completion was recorded." }, 502);
      return reply({ success: true });
    }

    const response = await deleteVisitorIntakeRow(selected.rowNumber);
    if (!response.ok) return reply({ error: "The entry could not be deleted. No completion was recorded." }, 502);
    return reply({ success: true });
  } catch {
    return reply({ error: "The visitor-intake sheet is unavailable right now. No completion was recorded." }, 503);
  }
}
