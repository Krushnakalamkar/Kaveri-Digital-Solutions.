import { getAdmin } from "@/server/auth";
import { requestUpload, uploadSchema } from "@/server/storage";
import { clientIdentifier, consumeLimit, sameOrigin } from "@/server/security";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "Request not allowed." }, { status: 403 });
  try {
    const input = uploadSchema.parse(await request.json());
    const admin = await getAdmin();
    if (input.kind !== "attachment" && !admin) {
      return Response.json({ error: "Please sign in again." }, { status: 401 });
    }
    const allowed = await consumeLimit(`upload:${await clientIdentifier()}`, admin ? 100 : 8, 3600);
    if (!allowed) return Response.json({ error: "Too many uploads. Please try again later." }, { status: 429 });
    return Response.json(await requestUpload(input, admin?.id));
  } catch {
    return Response.json({ error: "Use a JPEG, PNG, WebP (up to 5 MB) or PDF (up to 10 MB)." }, { status: 400 });
  }
}