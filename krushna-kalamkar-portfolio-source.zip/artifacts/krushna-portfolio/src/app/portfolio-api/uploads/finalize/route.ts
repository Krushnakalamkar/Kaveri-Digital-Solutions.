import { z } from "zod";
import { getAdmin } from "@/server/auth";
import { finalizeUpload } from "@/server/storage";
import { sameOrigin } from "@/server/security";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "Request not allowed." }, { status: 403 });
  try {
    const input = z.object({ uploadId: z.string().uuid(), token: z.string().length(64) }).parse(await request.json());
    const admin = await getAdmin();
    return Response.json(await finalizeUpload(input.uploadId, input.token, admin?.id));
  } catch {
    return Response.json({ error: "The file could not be verified. Please upload it again." }, { status: 400 });
  }
}