import { z } from "zod";
import { ReplitConnectors } from "@replit/connectors-sdk";
import { prisma } from "@/server/db";
import { clientIdentifier, consumeLimit, sameOrigin } from "@/server/security";

const enquiryRecipient = "kalamkarkrushna007@gmail.com";
const optionalText = (max: number) => z.string().trim().max(max).optional().or(z.literal(""));
const contactSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(254),
  phone: optionalText(40),
  service: optionalText(160),
  projectType: optionalText(160),
  budget: optionalText(100),
  message: z.string().trim().min(10).max(10000),
  attachmentUrl: optionalText(300),
  website: optionalText(200),
});

function encodeMimeBody(value: string) {
  return Buffer.from(value, "utf8").toString("base64").replace(/.{1,76}/g, "$&\r\n").trimEnd();
}

function buildGmailMessage(message: {
  name: string;
  email: string;
  phone: string | null;
  service: string | null;
  projectType: string | null;
  budget: string | null;
  message: string;
}) {
  const text = [
    `Name: ${message.name}`,
    `Email: ${message.email}`,
    message.phone ? `Phone: ${message.phone}` : null,
    message.service ? `Service: ${message.service}` : null,
    message.projectType ? `Project type: ${message.projectType}` : null,
    message.budget ? `Budget: ${message.budget}` : null,
    "",
    "Message:",
    message.message,
  ].filter((line): line is string => line !== null).join("\r\n");

  const rfcMessage = [
    `To: ${enquiryRecipient}`,
    `Reply-To: ${message.email}`,
    "Subject: New website enquiry",
    "MIME-Version: 1.0",
    "Content-Type: text/plain; charset=UTF-8",
    "Content-Transfer-Encoding: base64",
    "",
    encodeMimeBody(text),
  ].join("\r\n");

  return Buffer.from(rfcMessage, "utf8").toString("base64url");
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "Request not allowed." }, { status: 403 });
  if (Number(request.headers.get("content-length") ?? 0) > 32000) {
    return Response.json({ error: "Please shorten your message." }, { status: 413 });
  }
  try {
    const data = contactSchema.parse(await request.json());
    if (data.website) return Response.json({ success: true });
    if (!await consumeLimit(`contact:${await clientIdentifier()}`, 5, 3600)) {
      return Response.json({ error: "Too many enquiries. Please try later or email directly." }, { status: 429 });
    }
    if (data.attachmentUrl) {
      const id = /^\/portfolio-api\/media\/([a-f0-9-]{36})$/.exec(data.attachmentUrl)?.[1];
      const attachment = id && await prisma.mediaUpload.findFirst({
        where: { id, finalized: true, kind: "attachment", expiresAt: { gt: new Date() } },
      });
      if (!attachment || await prisma.contactMessage.count({ where: { attachmentUrl: data.attachmentUrl } })) {
        return Response.json({ error: "Please upload your attachment again." }, { status: 400 });
      }
    }
    const message = await prisma.contactMessage.create({
      data: {
        name: data.name, email: data.email,
        phone: data.phone || null, service: data.service || null,
        projectType: data.projectType || null, budget: data.budget || null,
        message: data.message, attachmentUrl: data.attachmentUrl || null,
      },
    });
    // Keep the saved enquiry even if email delivery is unavailable, but never
    // report success to the visitor until Gmail confirms it accepted the message.
    try {
      const connectors = new ReplitConnectors();
      const response = await connectors.proxy("google-mail", "/gmail/v1/users/me/messages/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raw: buildGmailMessage(message) }),
      });
      if (!response.ok) {
        console.error(`Enquiry email delivery failed with status ${response.status}.`);
        return Response.json(
          { error: `Your enquiry was saved, but could not be emailed. Please retry or email ${enquiryRecipient} directly.` },
          { status: 502 },
        );
      }
    } catch {
      console.error("Enquiry email delivery failed.");
      return Response.json(
        { error: `Your enquiry was saved, but could not be emailed. Please retry or email ${enquiryRecipient} directly.` },
        { status: 502 },
      );
    }
    return Response.json({ success: true }, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return Response.json({ error: "Check your name, email and message (at least 10 characters)." }, { status: 400 });
    }
    console.error("Enquiry storage failed.");
    return Response.json({ error: "Your enquiry could not be saved. Please retry or email directly." }, { status: 503 });
  }
}