import { z } from "zod";
import { clientIdentifier, consumeLimit, sameOrigin } from "@/server/security";
import { appendVisitorIntake, visitorIntakeRegions } from "@/server/visitor-intake-sheet";

const intakeSchema = z.object({
  name: z.string().trim().min(2).max(100),
  age: z.coerce.number().int().min(1).max(120),
  state: z.enum(visitorIntakeRegions),
  consent: z.literal(true),
});

function getIndiaTimestamp(now = new Date()) {
  const dateParts = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).formatToParts(now);
  const date = Object.fromEntries(dateParts.map(({ type, value }) => [type, value]));
  const time = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
    timeZoneName: "short",
  }).format(now);

  return {
    date: `${date.day}/${date.month}/${date.year}`,
    time: time.toUpperCase(),
  };
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) {
    return Response.json({ error: "This request could not be verified. Refresh the page and try again." }, { status: 403 });
  }

  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 8_000) {
    return Response.json({ error: "Please check your details and try again." }, { status: 413 });
  }

  let input: z.infer<typeof intakeSchema>;
  try {
    input = intakeSchema.parse(await request.json());
  } catch {
    return Response.json({ error: "Check your name, age, state, and consent before continuing." }, { status: 400 });
  }

  try {
    if (!await consumeLimit(`visitor-intake:${await clientIdentifier()}`, 10, 3600)) {
      return Response.json({ error: "Too many attempts. Please wait a little and try again." }, { status: 429 });
    }

    const timestamp = getIndiaTimestamp();
    const response = await appendVisitorIntake([
      input.name,
      input.age,
      input.state,
      timestamp.date,
      timestamp.time,
      input.consent,
    ]);

    if (!response.ok) {
      console.error(`Visitor intake sheet append failed with status ${response.status}.`);
      return Response.json(
        { error: "We couldn’t save your details right now. Please try again." },
        { status: 502 },
      );
    }

    return Response.json({ success: true }, { status: 201 });
  } catch {
    console.error("Visitor intake could not be saved to the connected sheet.");
    return Response.json(
      { error: "We couldn’t save your details right now. Please try again." },
      { status: 503 },
    );
  }
}
