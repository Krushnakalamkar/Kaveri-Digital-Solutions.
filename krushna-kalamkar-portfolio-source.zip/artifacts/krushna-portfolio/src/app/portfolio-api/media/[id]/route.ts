import { getAdmin } from "@/server/auth";
import { prisma } from "@/server/db";
import { streamMedia } from "@/server/storage";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[a-f0-9-]{36}$/.test(id)) return new Response("Not found", { status: 404 });
  try {
    const media = await prisma.mediaUpload.findFirst({ where: { id, finalized: true } });
    if (!media) return new Response("Not found", { status: 404 });
    const url = `/portfolio-api/media/${id}`;
    const [portrait, projectImage, resume, admin] = await Promise.all([
      prisma.profile.count({ where: { photoUrl: url } }),
      prisma.projectImage.count({ where: { imageUrl: url, project: { published: true } } }),
      prisma.resume.count({ where: { fileUrl: url, active: true } }),
      getAdmin(),
    ]);
    const isPublic = media.kind !== "attachment" && Boolean(portrait || projectImage || resume);
    if (!isPublic && !admin) return new Response("Not found", { status: 404 });
    return streamMedia(
      media.objectKey, media.mimeType, media.size, media.originalName,
      media.kind === "attachment" || new URL(request.url).searchParams.has("download"), isPublic,
    );
  } catch {
    return new Response("File unavailable", { status: 503 });
  }
}