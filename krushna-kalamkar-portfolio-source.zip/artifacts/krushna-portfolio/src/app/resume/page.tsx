import Link from 'next/link';
import { Download, Mail } from 'lucide-react';
import { getProfile, getResume } from '@/server/queries';
import { pageMetadata } from '@/server/metadata';

export const generateMetadata = () => pageMetadata('/resume', 'Resume');
import { object, value } from '@/components/site/content';
import { Ic } from '@/components/site/icons';
import { PageHero, SiteShell } from '@/components/site/site-chrome';

export default async function ResumePage() {
  const [resumeResult, profileResult] = await Promise.all([getResume(), getProfile()]);
  const resume = object(resumeResult);
  const profile = object(profileResult);
  const url = value(resume, 'fileUrl', 'url', 'downloadUrl');
  return <SiteShell>
    <PageHero eyebrow="RESUME" title={<>My<br /><em>résumé.</em></>} subtitle={[value(profile, 'professionalTitle'), value(profile, 'experience')].filter(Boolean).join(' · ')} />
    <section className="content-section narrow">
      <div className="resume-public">
        {url ? <>
          <p>{value(resume, 'summary', 'description') || 'Download the current résumé.'}</p>
          <a className="button-light focus-ring" href={url} download data-testid="link-resume-download"><Ic icon={Download} />Download résumé</a>
        </> : <>
          <p>I haven’t published a résumé here yet. Get in touch to ask about my experience.</p>
          <Link className="button-light focus-ring" href="/contact"><Ic icon={Mail} />Ask about my experience</Link>
        </>}
      </div>
    </section>
  </SiteShell>;
}
