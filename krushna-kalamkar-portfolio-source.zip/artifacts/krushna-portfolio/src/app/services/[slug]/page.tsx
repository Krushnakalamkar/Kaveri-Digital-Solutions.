import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, ArrowUpRight } from 'lucide-react';
import { getServiceBySlug } from '@/server/queries';
import { object, list, value } from '@/components/site/content';
import { PageHero, SiteShell } from '@/components/site/site-chrome';
import { pageMetadata } from '@/server/metadata';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = await getServiceBySlug(slug);
  return pageMetadata(`/services/${slug}`, service?.name ?? 'Service', service?.description);
}

export default async function ServiceDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = object(await getServiceBySlug(slug));
  const name = value(service, 'name', 'title');
  if (!name) notFound();
  const description = value(service, 'description', 'details');
  return <SiteShell>
    <PageHero eyebrow={`SERVICES / ${value(object(service.category), 'name', 'title')}`} title={<>{name}<em>.</em></>} subtitle={value(service, 'summary') || description} />
    <section className="content-section narrow">
      <Link href="/services" className="dark-text-link"><ArrowLeft size={15} /> All services</Link>
      {description ? <p className="detail-description">{description}</p> : <p className="data-empty-note">Additional service details will be published here.</p>}
      {value(service, 'details') && value(service, 'details') !== description ? <p className="detail-description">{value(service, 'details')}</p> : null}
      {list(service.services).length ? <div className="category-services">{list(service.services).map(item => <p key={value(item, 'id')}><Link href={`/services/${value(item, 'slug')}`}>{value(item, 'name')}</Link></p>)}</div> : null}
      <Link href="/contact" className="button-primary focus-ring">Discuss a project <ArrowUpRight size={16} /></Link>
    </section>
  </SiteShell>;
}