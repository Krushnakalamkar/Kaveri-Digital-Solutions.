import { getServiceCategories } from '@/server/queries';
import { pageMetadata } from '@/server/metadata';
import { ServicesList } from '@/components/site/content';
import { PageHero, SiteShell } from '@/components/site/site-chrome';

export const generateMetadata = () => pageMetadata('/services', 'Services');
export default async function ServicesPage() {
  const services = await getServiceCategories();
  return <SiteShell>
    <PageHero eyebrow="SERVICES / DIGITAL SOLUTIONS" title={<>What I Can Help<br /><em>You Build.</em></>} subtitle="A flexible mix of development, AI-led solutions and creative digital support." />
    <section className="content-section">
      <div className="section-topline"><p className="eyebrow">Services / By category</p><span>FROM KRUSHNA KALAMKAR</span></div>
      <div style={{ paddingTop: 25 }}><ServicesList data={services} /></div>
    </section>
  </SiteShell>;
}