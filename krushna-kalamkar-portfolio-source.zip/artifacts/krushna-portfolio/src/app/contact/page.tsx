import { MapPin } from 'lucide-react';
import { ContactForm } from '@/components/site/contact-form';
import { getServices, getProfile } from '@/server/queries';
import { pageMetadata } from '@/server/metadata';

export const generateMetadata = () => pageMetadata('/contact', 'Contact');
import { list, value } from '@/components/site/content';
import { Ic, Instagram, Linkedin, Mail, Phone } from '@/components/site/icons';
import { PageHero, SiteShell } from '@/components/site/site-chrome';

export default async function ContactPage() {
  const services = list(await getServices()).map(s => value(s, 'name')).filter(Boolean);
  const profile = await getProfile();
  return <SiteShell>
    <PageHero eyebrow="CONTACT" title={<>Let’s make<br /><em>something matter.</em></>} subtitle="Have a clear brief or just the beginning of an idea? Tell me where you want to go." />
    <section className="content-section public-contact">
      <div>
        <p className="eyebrow burgundy"><Ic icon={MapPin} size={13} /> {profile.location}</p>
        <div className="contact-links-stack">
          <a href={`mailto:${profile.email}`}><span><Ic icon={Mail} size={12} /> PRIMARY EMAIL</span>{profile.email}</a>
          <a href={`mailto:${profile.businessEmail}`}><span><Ic icon={Mail} size={12} /> BUSINESS EMAIL</span>{profile.businessEmail}</a>
          <a href={`tel:${profile.phone.replace(/[^\d+]/g, '')}`}><span><Ic icon={Phone} size={12} /> PHONE</span>{profile.phone}</a>
          {profile.socialLinks.map(link => <a key={link.platform} href={link.url} target="_blank" rel="noreferrer"><span><Ic icon={link.platform === 'instagram' ? Instagram : Linkedin} size={12} /> {link.label.toUpperCase()}</span>{link.url.replace(/^https?:\/\//, '').replace(/\/$/, '')}</a>)}
        </div>
      </div>
      <div className="contact-form-panel"><ContactForm services={services} /></div>
    </section>
  </SiteShell>;
}
