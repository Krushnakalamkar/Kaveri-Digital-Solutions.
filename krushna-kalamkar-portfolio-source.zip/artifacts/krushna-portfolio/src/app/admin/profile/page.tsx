import { getProfile } from '@/server/queries';
import { saveProfile } from '@/server/actions';
import { AdminShell, AdminForm, object } from '@/components/admin/admin-ui';

export default async function ProfileAdmin() {
  const p = object(await getProfile());
  return <AdminShell current="/admin/profile" title="Profile" description="Public name, tagline and about copy."><div className="admin-panel"><AdminForm action={saveProfile} values={{ ...p, role: p.role ?? p.professionalTitle, about: p.about ?? p.biography }} fields={[
    { name: 'name', label: 'Name' }, { name: 'role', label: 'Professional title' }, { name: 'location', label: 'Location' }, { name: 'experience', label: 'Experience' },
    { name: 'email', label: 'Primary email', type: 'email' }, { name: 'businessEmail', label: 'Business email', type: 'email' }, { name: 'phone', label: 'Phone' },
    { name: 'tagline', label: 'Tagline', type: 'textarea' }, { name: 'intro', label: 'Intro', type: 'textarea' }, { name: 'about', label: 'About', type: 'textarea' },
    { name: 'photoUrl', label: 'Portrait photo', type: 'upload', kind: 'image' }]} /></div></AdminShell>;
}
