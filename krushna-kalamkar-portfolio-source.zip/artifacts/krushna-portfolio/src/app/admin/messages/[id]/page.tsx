import { notFound } from 'next/navigation';
import { getMessageById } from '@/server/queries';
import { deleteMessage, setMessageStatus } from '@/server/actions';
import { AdminShell, ConfirmDelete, QuickAction, StatusPill, object, value } from '@/components/admin/admin-ui';

export default async function MessageDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const m = object(await getMessageById(id));
  if (!Object.keys(m).length) notFound();
  const status = value(m, 'status') || 'new';
  return <AdminShell current="/admin/messages" title={value(m, 'subject') || 'Message'} eyebrow="MESSAGES" actions={<StatusPill status={status} />}>
    <div className="admin-panel"><p className="admin-form-help">From {value(m, 'name')} · <a href={`mailto:${value(m, 'email')}`}>{value(m, 'email')}</a></p>
      <div className="admin-message-body">{value(m, 'message', 'body')}</div>
      <div className="admin-form-actions"><QuickAction action={setMessageStatus} id={id} extra={{ status: 'read' }} label="Mark read" icon="check" /><QuickAction action={setMessageStatus} id={id} extra={{ status: 'new' }} label="Mark unread" icon="hide" /><ConfirmDelete action={deleteMessage} id={id} label="this message" /></div></div>
  </AdminShell>;
}
