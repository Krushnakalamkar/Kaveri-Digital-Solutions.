import Link from 'next/link';
import { getMessages } from '@/server/queries';
import { deleteMessage } from '@/server/actions';
import { AdminShell, ConfirmDelete, Empty, StatusPill, idOf, value } from '@/components/admin/admin-ui';
import { list } from '@/components/site/content';

export default async function MessagesAdmin() {
  const rows = list(await getMessages());
  return <AdminShell current="/admin/messages" title="Messages" description="Enquiries from the contact form.">
    {!rows.length ? <Empty title="No messages yet" text="New enquiries will appear here." /> :
    <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>FROM</th><th>SUBJECT</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>
      {rows.map(m => { const id = idOf(m); return <tr key={id}><td>{value(m, 'name')}<br /><small>{value(m, 'email')}</small></td><td>{value(m, 'subject')}</td><td><StatusPill status={value(m, 'status') || 'new'} /></td>
        <td><div className="admin-inline-actions"><Link className="admin-button secondary" href={`/admin/messages/${id}`}>Open</Link><ConfirmDelete action={deleteMessage} id={id} label="this message" /></div></td></tr>; })}
    </tbody></table></div>}
  </AdminShell>;
}
