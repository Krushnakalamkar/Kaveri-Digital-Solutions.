import Link from 'next/link';
import { getDashboardSummary } from '@/server/queries';
import { AdminShell, object } from '@/components/admin/admin-ui';

export default async function DashboardPage() {
  const s = object(await getDashboardSummary());
  const stats = Object.entries(s).filter(([, v]) => typeof v === 'number');
  return <AdminShell current="/admin/dashboard" title="Dashboard" description="A live summary of the site content.">
    {stats.length ? <div className="admin-stats">{stats.map(([k, v]) => <div className="admin-stat" key={k}><span>{k.replace(/([A-Z])/g, ' $1').toUpperCase()}</span><b>{String(v)}</b></div>)}</div> : <div className="admin-empty"><h2>No summary yet</h2><p>Figures will appear as content is added.</p></div>}
    <div className="admin-panel"><h2>Quick links</h2><div className="admin-inline-actions">
      <Link className="admin-button" href="/admin/projects/new">New project</Link>
      <Link className="admin-button secondary" href="/admin/messages">Read messages</Link>
      <Link className="admin-button secondary" href="/admin/resume">Manage resume</Link></div></div>
  </AdminShell>;
}
