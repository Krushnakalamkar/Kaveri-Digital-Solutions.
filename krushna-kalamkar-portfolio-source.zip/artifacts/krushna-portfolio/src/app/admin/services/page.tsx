import { Plus } from 'lucide-react';
import { getServiceCategories } from '@/server/queries';
import { deleteCategory, deleteService, moveCategory, moveService, saveCategory, saveService, toggleService } from '@/server/actions';
import { AdminShell, AdminForm, ConfirmDelete, Empty, QuickAction, StatusPill, idOf, object, value, type Field } from '@/components/admin/admin-ui';
import { Ic, categoryIconNames } from '@/components/site/icons';
import { list } from '@/components/site/content';

const categoryFields: Field[] = [
  { name: 'name', label: 'Category name', required: true }, { name: 'slug', label: 'Slug' },
  { name: 'icon', label: 'Category icon', type: 'select', options: Object.keys(categoryIconNames) },
  { name: 'description', label: 'Description', type: 'textarea' }, { name: 'active', label: 'Visible on site', type: 'checkbox' },
];
const serviceFields: Field[] = [
  { name: 'name', label: 'Service name', required: true }, { name: 'slug', label: 'Slug' },
  { name: 'description', label: 'Short description', type: 'textarea' }, { name: 'details', label: 'Details', type: 'textarea' },
  { name: 'active', label: 'Visible on site', type: 'checkbox' },
];

export default async function ServicesAdmin() {
  const cats = list(await getServiceCategories({ admin: true }));
  return <AdminShell current="/admin/services" title="Services" description="Manage categories and the services inside them.">
    {!cats.length ? <Empty title="No categories yet" text="Create a category first, then add services to it." /> : cats.map(c => {
      const cid = idOf(c); const services = list(c.services);
      return <details className="admin-category" key={cid} open={cats.length === 1}>
        <summary><span>{value(c, 'name')} <small>({services.length})</small></span><StatusPill status={c.active === false ? 'hidden' : 'active'} /></summary>
        <div className="admin-category-body">
          <div className="admin-inline-actions">
            <QuickAction action={moveCategory} id={cid} extra={{ direction: 'up' }} label="Move category up" icon="up" />
            <QuickAction action={moveCategory} id={cid} extra={{ direction: 'down' }} label="Move category down" icon="down" />
            <ConfirmDelete action={deleteCategory} id={cid} label={`category ${value(c, 'name')} and its services`} />
          </div>
          <p className="admin-subhead">CATEGORY DETAILS</p>
          <AdminForm action={saveCategory} values={c} hidden={{ id: cid }} fields={categoryFields} />
          <p className="admin-subhead">SERVICES</p>
          {services.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>SERVICE</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>
            {services.map(s => { const id = idOf(s); const on = s.active !== false;
              return <tr key={id}><td>{value(s, 'name')}</td><td><StatusPill status={on ? 'active' : 'hidden'} /></td><td><div className="admin-inline-actions">
                <QuickAction action={moveService} id={id} extra={{ direction: 'up' }} label="Move service up" icon="up" />
                <QuickAction action={moveService} id={id} extra={{ direction: 'down' }} label="Move service down" icon="down" />
                <QuickAction action={toggleService} id={id} label={on ? 'Hide' : 'Show'} icon={on ? 'hide' : 'show'} />
                <ConfirmDelete action={deleteService} id={id} label={value(s, 'name') || 'service'} /></div></td></tr>; })}
          </tbody></table></div> : <p className="admin-form-help">No services in this category yet.</p>}
          {services.map(s => <details key={`e-${idOf(s)}`} className="admin-category"><summary>Edit {value(s, 'name')}</summary><div className="admin-category-body">
            <AdminForm action={saveService} values={object(s)} hidden={{ id: idOf(s), categoryId: cid }} fields={serviceFields} /></div></details>)}
          <details className="admin-category"><summary><span><Ic icon={Plus} /> Add service to {value(c, 'name')}</span></summary><div className="admin-category-body">
            <AdminForm action={saveService} hidden={{ categoryId: cid }} fields={serviceFields} submit="Add service" /></div></details>
        </div>
      </details>;
    })}
    <div className="admin-panel" style={{ marginTop: 22 }}><h2>Add category</h2><AdminForm action={saveCategory} fields={categoryFields} submit="Add category" /></div>
  </AdminShell>;
}
