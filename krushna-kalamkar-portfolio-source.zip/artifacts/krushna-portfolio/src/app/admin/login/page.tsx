import { LogIn } from 'lucide-react';
import Image from 'next/image';
import { authenticateAdmin } from '@/server/actions';
import { Ic } from '@/components/site/icons';
import { act } from '@/components/admin/admin-ui';

export const metadata = { title: 'Admin sign in', robots: { index: false } };

export default async function LoginPage({ searchParams }: { searchParams?: Promise<{ error?: string }> }) {
  const error = (await searchParams)?.error;
  return <main className="admin-login"><div className="admin-login-panel">
    <div className="admin-logo admin-login-brand"><Image src="/images/kaveri-logo.png" alt="Kaveri Digital Solutions" width={430} height={440} sizes="120px" priority className="admin-brand-logo" /></div>
    <h1>Studio sign in</h1><p>Authorised access only. Manage projects, services and messages.</p>
    {error ? <p className="admin-alert" role="alert">Those details did not match. Please try again.</p> : null}
    <form className="admin-form" action={act(authenticateAdmin)}>
      <div className="admin-field"><label htmlFor="email">Email</label><input id="email" name="email" type="email" autoComplete="username" required /></div>
      <div className="admin-field"><label htmlFor="password">Password</label><input id="password" name="password" type="password" autoComplete="current-password" required /></div>
      <button className="admin-button" type="submit"><Ic icon={LogIn} />Sign in</button>
    </form></div></main>;
}
