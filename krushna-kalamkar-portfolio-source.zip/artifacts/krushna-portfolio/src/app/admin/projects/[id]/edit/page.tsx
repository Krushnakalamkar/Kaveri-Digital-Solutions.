import { notFound } from 'next/navigation';
import { getProjectById } from '@/server/queries';
import { saveProject } from '@/server/actions';
import { AdminShell, AdminForm, object } from '@/components/admin/admin-ui';
import { projectFields } from '../../fields';

export default async function EditProject({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = object(await getProjectById(id));
  if (!Object.keys(project).length) notFound();
  return <AdminShell current="/admin/projects" title="Edit project" eyebrow="PROJECTS"><div className="admin-panel"><AdminForm action={saveProject} fields={projectFields} values={{ ...project, technologies: Array.isArray(project.technologies) ? project.technologies.join(', ') : project.technologies, shortDescription: project.shortDescription ?? project.summary }} hidden={{ id }} /></div></AdminShell>;
}
