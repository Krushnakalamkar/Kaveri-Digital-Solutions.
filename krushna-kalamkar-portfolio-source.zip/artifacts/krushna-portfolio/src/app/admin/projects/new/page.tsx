import { saveProject } from '@/server/actions';
import { AdminShell, AdminForm } from '@/components/admin/admin-ui';
import { projectFields } from '../fields';

export default function NewProject() {
  return <AdminShell current="/admin/projects" title="New project" eyebrow="PROJECTS"><div className="admin-panel"><AdminForm action={saveProject} fields={projectFields} submit="Create project" /></div></AdminShell>;
}
