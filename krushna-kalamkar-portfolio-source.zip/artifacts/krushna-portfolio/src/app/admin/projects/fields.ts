import type { Field } from '@/components/admin/admin-ui';
export const projectFields: Field[] = [
  { name: 'title', label: 'Title', required: true }, { name: 'slug', label: 'URL slug', help: 'Lowercase letters and hyphens.' },
  { name: 'category', label: 'Category' }, { name: 'liveUrl', label: 'Live URL', type: 'url' },
  { name: 'githubUrl', label: 'GitHub URL', type: 'url' }, { name: 'technologies', label: 'Technologies', help: 'Comma-separated, for example: Next.js, PostgreSQL.' },
  { name: 'shortDescription', label: 'Short description', type: 'textarea' }, { name: 'description', label: 'Description', type: 'textarea' },
  { name: 'challenge', label: '01 Challenge', type: 'textarea' }, { name: 'approach', label: '02 Approach', type: 'textarea' },
  { name: 'development', label: '03 Development', type: 'textarea' }, { name: 'result', label: '04 Result', type: 'textarea', help: 'Only enter outcomes that are verified.' },
  { name: 'images', label: 'Project images', type: 'images' },
  { name: 'published', label: 'Published', type: 'checkbox' }, { name: 'featured', label: 'Featured', type: 'checkbox' },
];
