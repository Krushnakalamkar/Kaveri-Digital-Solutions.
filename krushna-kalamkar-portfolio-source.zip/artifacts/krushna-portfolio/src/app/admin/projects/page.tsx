import Link from 'next/link';
import { Pencil, Plus } from 'lucide-react';
import { getProjects } from '@/server/queries';
import { deleteProject, setProjectFeatured, setProjectPublish } from '@/server/actions';
import { AdminShell, ConfirmDelete, Empty, QuickAction, StatusPill, idOf, value } from '@/components/admin/admin-ui';
import { Ic } from '@/components/site/icons';
import { list } from '@/components/site/content';

export default async function ProjectsAdmin() {
  const rows = list(await getProjects({ admin: true }));
  return <AdminShell current="/admin/projects" title="Projects" description="Only published projects appear on the public site." actions={<Link className="admin-button" href="/admin/projects/new"><Ic icon={Plus} />New project</Link>}>
    {!rows.length ? <Empty title="No projects yet" text="Add a verified project to start the Selected Work section." href="/admin/projects/new" label="Add first project" /> :
    <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>TITLE</th><th>STATUS</th><th>FEATURED</th><th>ACTIONS</th></tr></thead><tbody>
      {rows.map(p => { const id = idOf(p); const pub = p.published === true || p.isPublished === true; const feat = p.featured === true;
        return <tr key={id}><td>{value(p, 'title', 'name')}</td><td><StatusPill status={pub ? 'published' : 'draft'} /></td><td>{feat ? 'Yes' : 'No'}</td>
        <td><div className="admin-inline-actions">
          <Link className="admin-button secondary" href={`/admin/projects/${id}/edit`}><Ic icon={Pencil} />Edit</Link>
          <QuickAction action={setProjectPublish} id={id} extra={{ published: String(!pub) }} label={pub ? 'Unpublish' : 'Publish'} icon={pub ? 'hide' : 'show'} />
          <QuickAction action={setProjectFeatured} id={id} extra={{ featured: String(!feat) }} label={feat ? 'Unfeature' : 'Feature'} icon="star" />
          <ConfirmDelete action={deleteProject} id={id} label={value(p, 'title', 'name') || 'project'} /></div></td></tr>; })}
    </tbody></table></div>}
  </AdminShell>;
}
