import { getSettings } from '@/server/queries';
import { saveSettings } from '@/server/actions';
import { AdminShell, AdminForm, object } from '@/components/admin/admin-ui';

export default async function SettingsAdmin() {
  const s = object(await getSettings());
  return <AdminShell current="/admin/settings" title="Settings" description="Site-wide details."><div className="admin-panel"><AdminForm action={saveSettings} values={{ ...s, description: s.description ?? s.siteDescription }} fields={[
    { name: 'siteTitle', label: 'Site title' }, { name: 'canonicalUrl', label: 'Canonical URL', type: 'url' },
    { name: 'description', label: 'Meta description', type: 'textarea' },
    { name: 'businessEmail', label: 'Business email', type: 'email' }, { name: 'phone', label: 'Phone' },
    { name: 'instagramUrl', label: 'Instagram URL', type: 'url' }, { name: 'linkedinUrl', label: 'LinkedIn URL', type: 'url' }]} /></div></AdminShell>;
}
