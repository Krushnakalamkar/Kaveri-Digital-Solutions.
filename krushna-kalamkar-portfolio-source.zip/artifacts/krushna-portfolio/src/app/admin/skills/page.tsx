import { getSkills } from '@/server/queries';
import { deleteSkill, saveSkill } from '@/server/actions';
import type { Field } from '@/components/admin/admin-ui';
import { AdminShell, AdminForm, ConfirmDelete, Empty, StatusPill, idOf, value } from '@/components/admin/admin-ui';
import { list } from '@/components/site/content';

const skillFields: Field[] = [{ name: 'name', label: 'Skill', required: true }, { name: 'category', label: 'Category' }, { name: 'order', label: 'Order', type: 'number' }, { name: 'active', label: 'Visible on site', type: 'checkbox' }];

export default async function SkillsAdmin() {
  const rows = list(await getSkills({ admin: true }));
  return <AdminShell current="/admin/skills" title="Skills" description="Shown on the public skills section.">
    {!rows.length ? <Empty title="No skills yet" text="Add a skill below." /> :
    <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>SKILL</th><th>CATEGORY</th><th>ORDER</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>
      {rows.map(s => { const id = idOf(s); return <tr key={id}><td>{value(s, 'name', 'title')}</td><td>{value(s, 'category')}</td><td>{String(s.order ?? '')}</td><td><StatusPill status={s.active === false ? 'hidden' : 'active'} /></td><td><div className="admin-inline-actions"><ConfirmDelete action={deleteSkill} id={id} label={value(s, 'name', 'title') || 'skill'} /></div></td></tr>; })}
    </tbody></table></div>}
    {rows.map(sk => <details className="admin-category" key={idOf(sk)}><summary>Edit {value(sk, 'name')}</summary><div className="admin-category-body"><AdminForm action={saveSkill} values={sk} hidden={{ id: idOf(sk) }} fields={skillFields} /></div></details>)}
    <div className="admin-panel" style={{ marginTop: 24 }}><h2>Add skill</h2><AdminForm action={saveSkill} submit="Add skill" fields={skillFields} /></div>
  </AdminShell>;
}
