import { getResume } from '@/server/queries';
import { deleteResume, saveResume } from '@/server/actions';
import { AdminShell, AdminForm, ConfirmDelete, object, value } from '@/components/admin/admin-ui';

export default async function ResumeAdmin() {
  const r = object(await getResume());
  const has = Boolean(value(r, 'fileUrl'));
  return <AdminShell current="/admin/resume" title="Resume" description={has ? `Live on the public site: ${value(r, 'fileName') || 'résumé file'}.` : 'No résumé uploaded. The public résumé page invites visitors to get in touch.'}>
    <div className="admin-panel">
      <AdminForm action={saveResume} values={r} submit="Save resume" fields={[{ name: 'fileUrl', label: 'Résumé file (PDF)', type: 'upload', kind: 'resume', required: true }]} hidden={{ fileName: value(r, 'fileName'), mimeType: value(r, 'mimeType'), fileSize: String(r.fileSize ?? '') }} />
      {has ? <div style={{ marginTop: 18 }}><ConfirmDelete action={deleteResume} id={String(r.id ?? 'resume')} label="the résumé" /></div> : null}
    </div></AdminShell>;
}
