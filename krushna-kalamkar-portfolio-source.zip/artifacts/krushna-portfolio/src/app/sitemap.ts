import type { MetadataRoute } from "next";
import { prisma } from "@/server/db";
import { siteBaseUrl } from "@/server/metadata";

export const dynamic = "force-dynamic";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = await siteBaseUrl();
  if (!base) return [];
  const [projects, categories, services] = await Promise.all([
    prisma.project.findMany({ where: { published: true }, select: { slug: true, updatedAt: true } }),
    prisma.serviceCategory.findMany({ where: { active: true }, select: { slug: true, updatedAt: true } }),
    prisma.service.findMany({ where: { active: true, category: { active: true } }, select: { slug: true, updatedAt: true } }),
  ]);
  return [
    ...["/", "/about", "/services", "/work", "/resume", "/contact"].map(path => ({ url: new URL(path, base).href })),
    ...projects.map(item => ({ url: new URL(`/work/${item.slug}`, base).href, lastModified: item.updatedAt })),
    ...categories.map(item => ({ url: new URL(`/services/${item.slug}`, base).href, lastModified: item.updatedAt })),
    ...services.map(item => ({ url: new URL(`/services/${item.slug}`, base).href, lastModified: item.updatedAt })),
  ];
}