import type { Metadata } from 'next';
import './globals.css';
import { ThemeProvider } from 'next-themes';
import Script from 'next/script';
import { getProfile, getSettings } from '@/server/queries';
import { siteBaseUrl } from '@/server/metadata';
import { SiteDataProvider } from '@/components/site/site-data';

export const dynamic = 'force-dynamic';
export async function generateMetadata(): Promise<Metadata> {
  const [settings, base] = await Promise.all([getSettings(), siteBaseUrl()]);
  return {
    ...(base ? { metadataBase: base } : {}),
    title: { default: settings.siteTitle, template: `%s | ${settings.siteTitle}` },
    description: settings.description,
    icons: { icon: { url: '/images/kaveri-icon.png', type: 'image/png', sizes: '260x260' } },
    openGraph: { title: settings.siteTitle, siteName: settings.siteTitle, description: settings.description, type: 'website' },
    twitter: { card: 'summary', title: settings.siteTitle, description: settings.description },
  };
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const [profile, settings] = await Promise.all([getProfile(), getSettings()]);
  return <html lang="en" data-scroll-behavior="smooth" suppressHydrationWarning><body><Script id="visitor-intake-completion" strategy="beforeInteractive">{`try { if (window.localStorage.getItem('kaveri-visitor-intake-complete') === 'true') document.documentElement.classList.add('visitor-intake-complete'); } catch {}`}</Script><ThemeProvider attribute="data-theme" defaultTheme="dark" enableSystem={false} storageKey="kaveri-portfolio-theme"><SiteDataProvider profile={{
    companyName: settings.siteTitle, name: profile.name, professionalTitle: profile.professionalTitle, location: profile.location,
    email: profile.email, businessEmail: profile.businessEmail, phone: profile.phone,
    photoUrl: profile.photoUrl, socialLinks: profile.socialLinks,
  }}>{children}</SiteDataProvider></ThemeProvider></body></html>;
}