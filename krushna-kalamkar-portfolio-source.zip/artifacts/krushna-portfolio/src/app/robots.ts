import type { MetadataRoute } from "next";
import { siteBaseUrl } from "@/server/metadata";

export const dynamic = "force-dynamic";
export default async function robots(): Promise<MetadataRoute.Robots> {
  const base = await siteBaseUrl();
  return {
    rules: { userAgent: "*", allow: "/", disallow: ["/admin", "/portfolio-api"] },
    ...(base ? { sitemap: new URL("/sitemap.xml", base).href } : {}),
  };
}