import Link from 'next/link';
import { ArrowDown, ArrowRight, ArrowUpRight } from 'lucide-react';
import { getProfile, getProjects, getSkills, getServiceCategories, getResume, getSettings } from '@/server/queries';
import { pageMetadata } from '@/server/metadata';
import { Portrait, SiteShell } from '@/components/site/site-chrome';
import { list, object, ProjectCards, ServicesList, value } from '@/components/site/content';

export async function generateMetadata() {
  const settings = await getSettings();
  return { ...await pageMetadata('/', settings.siteTitle), title: { absolute: settings.siteTitle } };
}

export default async function HomePage() {
  const [profileResult, projectsResult, skillsResult, categories, resume] = await Promise.all([
    getProfile(), getProjects(), getSkills(), getServiceCategories(), getResume(),
  ]);
  const profile = object(profileResult);
  const projects = list(projectsResult).filter(project => project.published === true || project.isPublished === true || value(project, 'status').toLowerCase() === 'published');
  const skills = list(skillsResult);
  const name = value(profile, 'name') || 'Krushna Kalamkar';
  const firstName = name.trim().split(/\s+/)[0];
  const categoryRows = list(categories);
  const serviceCount = categoryRows.reduce((total, category) => total + list(category.services).length, 0);
  const introduction = value(profile, 'biography', 'about', 'intro');
  const tagline = value(profile, 'tagline');
  const hasPersonalTagline = tagline && tagline !== 'Building Digital Solutions That Move Your Ideas Forward.';
  return <SiteShell>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({
      '@context': 'https://schema.org', '@type': 'Person', name: value(profile, 'name'),
      jobTitle: value(profile, 'professionalTitle'), description: value(profile, 'biography'),
      email: value(profile, 'email'), telephone: value(profile, 'phone'),
      sameAs: list(profile.socialLinks).map(link => value(link, 'url')),
    }).replace(/</g, '\\u003c') }} />
    <section className="hero-next">
      <div className="hero-next-copy">
        <h1>Hi, I’m<br /><span>{firstName}.</span></h1>
        <p className="hero-next-role">{value(profile, 'professionalTitle')} <span className="role-divider">/</span> {value(profile, 'location')}</p>
        {hasPersonalTagline ? <p className="hero-next-tagline">{tagline}</p> : null}
        {introduction ? <p className="hero-personal-intro">{introduction}</p> : null}
        <div className="hero-actions-next"><Link className="button-primary focus-ring" href="/contact">Get in touch <ArrowUpRight size={16} /></Link><Link className="button-text focus-ring" href={projects.length ? '/work' : '/about'}>{projects.length ? 'View selected work' : 'More about me'} <ArrowRight size={15} /></Link></div>
        <div className="proof-strip">
          {value(profile, 'experience') ? <div><b>{value(profile, 'experience')}</b><span>Experience</span></div> : null}
          <div><b>{serviceCount}</b><span>Services across {categoryRows.length} categories</span></div>
        </div>
      </div>
      <Portrait />
    </section>
    <section className="home-services"><div className="content-section"><div className="services-heading-row"><h2 className="display section-heading">Services<br /><em>I offer.</em></h2><Link className="button-light focus-ring" href="/services">Explore services <ArrowUpRight size={16} /></Link></div><ServicesList data={categories} /></div></section>
    {projects.length ? <section className="content-section"><div className="section-topline"><p className="eyebrow">Selected work</p><span>{projects.length} PUBLISHED PROJECT{projects.length === 1 ? '' : 'S'}</span></div><div style={{ paddingTop: 28 }}><ProjectCards data={projects} /></div><Link href="/work" className="dark-text-link">See all projects <ArrowRight size={16} /></Link></section> : null}
    <section className="content-section skills-home" id="skills"><div className="section-topline"><p className="eyebrow">Skills</p>{skills.length ? <span>{skills.length} LISTED SKILLS</span> : null}</div><div className="skill-cloud">{skills.length ? skills.slice(0, 12).map((skill, i) => <span className="skill-tag" key={value(skill, 'id', 'name') || i}><i>{String(i + 1).padStart(2, '0')}</i>{value(skill, 'name', 'title')}</span>) : <p className="data-empty-note">I haven’t listed specific tools or skills here yet.</p>}</div></section>
    <section className="content-section"><div className="section-topline"><p className="eyebrow">Experience &amp; résumé</p></div><h2 className="display section-heading">Want more<br /><em>detail?</em></h2><p className="about-copy">{resume ? 'Download my current résumé for an overview of my experience.' : 'I haven’t posted a résumé here yet. Get in touch to ask about my experience.'}</p>{resume ? <a href={`${resume.fileUrl}?download=1`} className="button-primary focus-ring">Download résumé <ArrowDown size={16} /></a> : <Link href="/contact" className="dark-text-link">Ask about my experience <ArrowUpRight size={16} /></Link>}</section>
    <section className="site-callout"><div className="site-callout-inner"><h2>Have a question?<br />Write to me.</h2><Link href="/contact">Get in touch <ArrowUpRight size={16} /></Link></div></section>
  </SiteShell>;
}