'use client';

import { ArrowRight, LockKeyhole } from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { FormEvent, PointerEvent as ReactPointerEvent } from 'react';
import './visitor-intake.css';

const STORAGE_KEY = 'kaveri-visitor-intake-session-complete';
const useBrowserLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect;
const STATES_AND_TERRITORIES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
  'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Andaman and Nicobar Islands', 'Chandigarh', 'Dadra and Nagar Haveli and Daman and Diu',
  'Delhi', 'Jammu and Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry',
] as const;

type FormValues = { name: string; age: string; state: string; consent: boolean };
type FieldErrors = Partial<Record<keyof FormValues, string>>;
type PendingSubmission = { fingerprint: string; id: string };

const initialValues: FormValues = { name: '', age: '', state: '', consent: false };

function validate(values: FormValues): FieldErrors {
  const errors: FieldErrors = {};
  if (values.name.trim().length < 2) errors.name = 'Please enter at least 2 characters.';
  else if (values.name.trim().length > 100) errors.name = 'Name must be 100 characters or fewer.';

  const age = Number(values.age);
  if (!values.age) errors.age = 'Please enter your age.';
  else if (!Number.isInteger(age) || age < 1 || age > 120) errors.age = 'Enter a whole number from 1 to 120.';

  if (!values.state) errors.state = 'Choose your State or Union Territory.';
  if (!values.consent) errors.consent = 'Please confirm your consent to continue.';
  return errors;
}

export function VisitorIntake() {
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(true);
  const [values, setValues] = useState<FormValues>(initialValues);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [requestError, setRequestError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const dialogRef = useRef<HTMLElement>(null);
  const nameRef = useRef<HTMLInputElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);
  const reducedMotionRef = useRef(false);
  const pendingSubmissionRef = useRef<PendingSubmission | null>(null);

  useBrowserLayoutEffect(() => {
    setMounted(true);
    if (document.documentElement.classList.contains('visitor-intake-complete')) {
      setOpen(false);
      return;
    }
    try {
      if (window.sessionStorage.getItem(STORAGE_KEY) === 'true') {
        document.documentElement.classList.add('visitor-intake-complete');
        setOpen(false);
      }
    } catch {
      // The gate remains active if storage is unavailable.
    }
  }, []);

  useBrowserLayoutEffect(() => {
    if (!mounted || !open) return;
    const page = document.querySelector<HTMLElement>('.site-public');
    const previousOverflow = document.documentElement.style.overflow;
    const previousBodyOverflow = document.body.style.overflow;
    const previousOverscroll = document.body.style.overscrollBehavior;
    if (page) page.inert = true;
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    document.body.style.overscrollBehavior = 'none';
    previousFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    reducedMotionRef.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      if (event.key !== 'Tab' || !dialogRef.current) return;
      const focusable = Array.from(dialogRef.current.querySelectorAll<HTMLElement>(
        'input:not(:disabled), select:not(:disabled), button:not(:disabled), a[href], [tabindex]:not([tabindex="-1"])',
      ));
      if (!focusable.length) {
        event.preventDefault();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || !dialogRef.current.contains(document.activeElement))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !dialogRef.current.contains(document.activeElement))) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKeyDown, true);
    return () => {
      document.removeEventListener('keydown', onKeyDown, true);
      if (page) page.inert = false;
      document.documentElement.style.overflow = previousOverflow;
      document.body.style.overflow = previousBodyOverflow;
      document.body.style.overscrollBehavior = previousOverscroll;
    };
  }, [mounted, open]);

  useEffect(() => {
    if (!mounted || !open) return;
    nameRef.current?.focus({ preventScroll: true });
  }, [mounted, open]);

  useEffect(() => {
    if (open || !mounted) return;
    previousFocusRef.current?.focus();
  }, [mounted, open]);

  const setField = <K extends keyof FormValues>(field: K, value: FormValues[K]) => {
    setValues(current => ({ ...current, [field]: value }));
    setErrors(current => ({ ...current, [field]: undefined }));
    setRequestError('');
  };

  const onPointerMove = useCallback((event: ReactPointerEvent<HTMLElement>) => {
    if (reducedMotionRef.current || event.pointerType === 'touch') return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const rx = ((event.clientY - bounds.top) / bounds.height - .5) * -2.2;
    const ry = ((event.clientX - bounds.left) / bounds.width - .5) * 2.2;
    event.currentTarget.style.setProperty('--vi-rotate-x', `${rx.toFixed(2)}deg`);
    event.currentTarget.style.setProperty('--vi-rotate-y', `${ry.toFixed(2)}deg`);
  }, []);

  const onPointerLeave = useCallback((event: ReactPointerEvent<HTMLElement>) => {
    event.currentTarget.style.setProperty('--vi-rotate-x', '0deg');
    event.currentTarget.style.setProperty('--vi-rotate-y', '0deg');
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    const nextErrors = validate(values);
    setErrors(nextErrors);
    setRequestError('');
    if (Object.keys(nextErrors).length) {
      const firstInvalid = Object.keys(nextErrors)[0];
      dialogRef.current?.querySelector<HTMLElement>(`[name="${firstInvalid}"]`)?.focus();
      return;
    }

    setSubmitting(true);
    try {
      const submission = {
        name: values.name.trim(),
        age: Number(values.age),
        state: values.state,
        consent: true as const,
      };
      const fingerprint = JSON.stringify(submission);
      if (pendingSubmissionRef.current?.fingerprint !== fingerprint) {
        pendingSubmissionRef.current = {
          fingerprint,
          id: window.crypto.randomUUID(),
        };
      }

      const response = await fetch('/portfolio-api/visitor-intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...submission,
          submissionId: pendingSubmissionRef.current.id,
        }),
      });
      const result: { success?: boolean; error?: string } = await response.json().catch(() => ({}));
      if (!response.ok || result.success !== true) {
        throw new Error(result.error || 'We could not save your details. Please try again.');
      }
      pendingSubmissionRef.current = null;
      try {
        window.sessionStorage.setItem(STORAGE_KEY, 'true');
      } catch {
        // A successful submission still unlocks this visit when storage is unavailable.
      }
      document.documentElement.classList.add('visitor-intake-complete');
      setOpen(false);
    } catch (error) {
      setRequestError(error instanceof Error ? error.message : 'We could not save your details. Please try again.');
      requestAnimationFrame(() => dialogRef.current?.querySelector<HTMLElement>('[data-vi-error]')?.focus());
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) return null;

  return (
    <div
      className="visitor-intake"
      data-testid="visitor-intake-gate"
      onClick={event => event.stopPropagation()}
      onWheel={event => event.stopPropagation()}
      onTouchMove={event => event.stopPropagation()}
    >
      <section
        className="visitor-intake__card"
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="visitor-intake-heading"
        aria-describedby="visitor-intake-intro"
        tabIndex={-1}
        onPointerMove={onPointerMove}
        onPointerLeave={onPointerLeave}
      >
        <div className="visitor-intake__content">
          <div className="visitor-intake__brand" aria-label="Kaveri Digital Solutions">
            <img className="visitor-intake__logo" src="/images/kaveri-logo.png" alt="" width="47" height="47" />
            <span className="visitor-intake__brand-copy">
              <span className="visitor-intake__brand-name">KAVERI</span>
              <span className="visitor-intake__brand-sub">DIGITAL SOLUTIONS</span>
            </span>
          </div>
          <div className="visitor-intake__rule" aria-hidden="true" />
          <h1 className="visitor-intake__heading" id="visitor-intake-heading">Welcome to <span>Kaveri</span></h1>
          <p className="visitor-intake__intro" id="visitor-intake-intro">
            Your name, age, State or Union Territory, and consent are recorded in Kaveri’s Google Sheet for visitor insights, along with the date and time.
          </p>

          <form className="visitor-intake__form" onSubmit={handleSubmit} noValidate>
            <div className="visitor-intake__field">
              <label className="visitor-intake__label" htmlFor="visitor-name">Your name</label>
              <input
                ref={nameRef}
                className="visitor-intake__control"
                id="visitor-name"
                name="name"
                type="text"
                autoComplete="name"
                placeholder="How should I address you?"
                value={values.name}
                onChange={event => setField('name', event.target.value)}
                aria-invalid={Boolean(errors.name)}
                aria-describedby={errors.name ? 'visitor-name-error' : undefined}
                maxLength={100}
                required
                disabled={submitting}
                data-testid="input-visitor-name"
              />
              {errors.name ? <p className="visitor-intake__field-error" id="visitor-name-error">{errors.name}</p> : null}
            </div>

            <div className="visitor-intake__field">
              <label className="visitor-intake__label" htmlFor="visitor-age">Your age</label>
              <input
                className="visitor-intake__control"
                id="visitor-age"
                name="age"
                type="number"
                inputMode="numeric"
                min="1"
                max="120"
                step="1"
                placeholder="Enter your age"
                value={values.age}
                onChange={event => setField('age', event.target.value)}
                aria-invalid={Boolean(errors.age)}
                aria-describedby={errors.age ? 'visitor-age-error' : undefined}
                required
                disabled={submitting}
                data-testid="input-visitor-age"
              />
              {errors.age ? <p className="visitor-intake__field-error" id="visitor-age-error">{errors.age}</p> : null}
            </div>

            <div className="visitor-intake__field">
              <label className="visitor-intake__label" htmlFor="visitor-state">State or Union Territory</label>
              <div className="visitor-intake__control-wrap">
                <select
                  className="visitor-intake__control visitor-intake__select"
                  id="visitor-state"
                  name="state"
                  value={values.state}
                  onChange={event => setField('state', event.target.value)}
                  aria-invalid={Boolean(errors.state)}
                  aria-describedby={errors.state ? 'visitor-state-error' : undefined}
                  required
                  disabled={submitting}
                  data-testid="select-visitor-state"
                >
                  <option value="">Choose your location</option>
                  <optgroup label="States">
                    {STATES_AND_TERRITORIES.slice(0, 28).map(state => <option key={state} value={state}>{state}</option>)}
                  </optgroup>
                  <optgroup label="Union Territories">
                    {STATES_AND_TERRITORIES.slice(28).map(state => <option key={state} value={state}>{state}</option>)}
                  </optgroup>
                </select>
                <span className="visitor-intake__select-chevron" aria-hidden="true" />
              </div>
              {errors.state ? <p className="visitor-intake__field-error" id="visitor-state-error">{errors.state}</p> : null}
            </div>

            <div className="visitor-intake__consent">
              <input
                id="visitor-consent"
                name="consent"
                type="checkbox"
                checked={values.consent}
                onChange={event => setField('consent', event.target.checked)}
                aria-invalid={Boolean(errors.consent)}
                aria-labelledby="visitor-consent-label"
                aria-describedby={errors.consent ? 'visitor-consent-error' : undefined}
                required
                disabled={submitting}
                data-testid="checkbox-visitor-consent"
              />
              <span className="visitor-intake__consent-copy">
                <label id="visitor-consent-label" htmlFor="visitor-consent">
                  I agree to share these details with Kaveri Digital Solutions for visitor insights. If I’m under 18, a parent or guardian has reviewed this submission.
                </label>
                <Link className="visitor-intake__privacy-link" href="/privacy" target="_blank" rel="noreferrer">
                  Read the privacy notice
                </Link>
              </span>
            </div>
            {errors.consent ? <p className="visitor-intake__field-error" id="visitor-consent-error">{errors.consent}</p> : null}
            {requestError ? (
              <p className="visitor-intake__error" role="alert" tabIndex={-1} data-vi-error data-testid="status-visitor-error">
                {requestError}
              </p>
            ) : null}

            <button className="visitor-intake__submit" type="submit" disabled={submitting} data-testid="button-visitor-submit">
              {submitting ? <><span className="visitor-intake__spinner" aria-hidden="true" />Saving your details</> : <><ArrowRight aria-hidden="true" />Continue to the site</>}
            </button>
          </form>

          <p className="visitor-intake__privacy"><LockKeyhole size={11} aria-hidden="true" /> This browser stores only a completion marker, not the details you submit.</p>
          <p className="visitor-intake__footer">Kaveri Digital Solutions</p>
          <p className="visitor-intake__tagline">Build · Grow · Succeed</p>
        </div>
      </section>
    </div>
  );
}

export default VisitorIntake;
