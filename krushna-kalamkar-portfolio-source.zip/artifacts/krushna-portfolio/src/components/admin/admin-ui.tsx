import Link from 'next/link';
import Image from 'next/image';
import { Suspense } from 'react';
import { requireAdmin } from '@/server/auth';
import { isConfiguredOwner } from '@/server/owner-access';
import { StatusBanner } from '@/components/admin/status-banner';
import { ProjectImagesField, UploadField } from '@/components/admin/upload-field';
import { Check, Plus, Save, Trash2, ArrowUp, ArrowDown, Eye, EyeOff, Star } from 'lucide-react';
import { Ic, adminIcons } from '@/components/site/icons';
import { logoutAdmin } from '@/server/actions';
import { object, value, type DataObject } from '@/components/site/content';

export type FormAction = (formData: FormData) => void | Promise<void>;
export const act = (fn: unknown) => fn as FormAction;

const nav: [string, string, keyof typeof adminIcons][] = [
  ['Dashboard', '/admin/dashboard', 'dashboard'], ['Projects', '/admin/projects', 'projects'],
  ['Services', '/admin/services', 'services'], ['Messages', '/admin/messages', 'messages'],
  ['Privacy requests', '/admin/visitor-requests', 'visitorRequests'],
  ['Skills', '/admin/skills', 'skills'], ['Profile', '/admin/profile', 'profile'],
  ['Resume', '/admin/resume', 'resume'], ['Settings', '/admin/settings', 'settings'],
];

export async function AdminShell({ current, title, eyebrow = 'STUDIO', description, actions, children }: {
  current: string; title: string; eyebrow?: string; description?: string; actions?: React.ReactNode; children: React.ReactNode;
}) {
  const admin = await requireAdmin();
  const visibleNav = nav.filter(([, href]) => href !== '/admin/visitor-requests' || isConfiguredOwner(admin));
  return <div className="admin-shell">
    <aside className="admin-sidebar">
      <Link href="/admin/dashboard" className="admin-logo"><Image src="/images/kaveri-logo.png" alt="Kaveri Digital Solutions" width={430} height={440} sizes="80px" className="admin-brand-logo" /><small>STUDIO ADMIN</small></Link>
      <p className="admin-nav-label">MANAGE</p>
      <nav className="admin-nav" aria-label="Admin navigation">
        {visibleNav.map(([label, href, icon]) => <Link key={href} href={href} aria-current={current === href ? 'page' : undefined}><Ic icon={adminIcons[icon]} />{label}</Link>)}
      </nav>
      <div className="admin-sidebar-bottom">
        <Link href="/"><Ic icon={adminIcons.site} />View public site</Link>
        <form action={act(logoutAdmin)}><button type="submit" className="admin-signout"><Ic icon={adminIcons.logout} />Sign out</button></form>
      </div>
    </aside>
    <div className="admin-main">
      <div className="admin-topbar"><span>KRUSHNA KALAMKAR / ADMIN</span><Link href="/">Public site</Link></div>
       <nav className="admin-mobile-nav" aria-label="Admin sections">{visibleNav.map(([label, href]) => <Link key={href} href={href} aria-current={current === href ? 'page' : undefined}>{label}</Link>)}</nav>
      <main className="admin-content" id="main-content">
        <div className="admin-heading"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1>{description ? <p>{description}</p> : null}</div>{actions}</div>
        <Suspense fallback={null}><StatusBanner /></Suspense>
        {children}
      </main>
    </div>
  </div>;
}

export function Empty({ title, text, href, label }: { title: string; text: string; href?: string; label?: string }) {
  return <div className="admin-empty"><h2>{title}</h2><p>{text}</p>{href ? <Link className="admin-button" href={href}><Ic icon={Plus} />{label}</Link> : null}</div>;
}

export function StatusPill({ status }: { status: string }) {
  return <span className={`admin-status ${status.toLowerCase()}`}>{status || 'draft'}</span>;
}

export type Field = { name: string; label: string; type?: 'text' | 'email' | 'url' | 'number' | 'textarea' | 'checkbox' | 'upload' | 'images' | 'select'; kind?: 'image' | 'resume' | 'attachment'; full?: boolean; help?: string; options?: string[]; required?: boolean };

export function AdminForm({ action, fields, values = {}, submit = 'Save changes', hidden = {} }: {
  action: unknown; fields: Field[]; values?: DataObject; submit?: string; hidden?: Record<string, string>;
}) {
  const formId = String(hidden.id || values.id || hidden.categoryId || submit.replace(/\W/g, '-'));
  return <form action={act(action)} className="admin-form">
    {Object.entries(hidden).map(([k, v]) => <input type="hidden" name={k} value={v} key={k} />)}
    <div className="admin-form-grid">
      {fields.map(f => {
        const id = `f-${formId}-${f.name}`; const v = values[f.name];
        const wide = f.full || f.type === 'textarea' || f.type === 'upload' || f.type === 'images';
        return <div key={f.name} className={`admin-field ${wide ? 'full' : ''}`}>
          {f.type === 'upload' || f.type === 'images' ? null : f.type === 'checkbox'
            ? <label htmlFor={id} className="admin-check"><input type="hidden" name={`${f.name}Present`} value="true" /><input id={id} type="checkbox" name={f.name} defaultChecked={v === true || (f.name === 'active' && v === undefined)} /> {f.label}</label>
            : <label htmlFor={id}>{f.label}</label>}
          {f.type === 'images' ? <ProjectImagesField initial={Array.isArray(v) ? v.map(item => ({ imageUrl: value(object(item), 'imageUrl'), altText: value(object(item), 'altText') })) : []} /> :
            f.type === 'upload' ? <UploadField name={f.name} kind={f.kind ?? 'image'} label={f.label} defaultValue={typeof v === 'string' ? v : ''} required={f.required} /> :
           f.type === 'textarea' ? <textarea id={id} name={f.name} defaultValue={typeof v === 'string' ? v : ''} required={f.required} />
            : f.type === 'select' ? <select id={id} name={f.name} defaultValue={typeof v === 'string' ? v : ''}>{f.options?.map(o => <option key={o} value={o}>{o}</option>)}</select>
            : f.type === 'checkbox' ? null
            : <input id={id} name={f.name} type={f.type ?? 'text'} defaultValue={Array.isArray(v) ? v.join(', ') : (typeof v === 'string' || typeof v === 'number' ? String(v) : '')} required={f.required} />}
          {f.help ? <span className="admin-form-help">{f.help}</span> : null}
        </div>;
      })}
    </div>
    <div className="admin-form-actions"><button className="admin-button" type="submit"><Ic icon={Save} />{submit}</button></div>
  </form>;
}

/* Keyboard-operable two-step confirmation without client JS. */
export function ConfirmDelete({ action, id, label, name = 'id' }: { action: unknown; id: string; label: string; name?: string }) {
  return <details className="admin-confirm">
    <summary className="admin-button secondary" aria-label={`Delete ${label}`}><Ic icon={Trash2} />Delete</summary>
    <form action={act(action)}><input type="hidden" name={name} value={id} />
      <p className="admin-form-help" role="alert">Delete {label}? This cannot be undone.</p>
      <button type="submit" className="admin-button danger"><Ic icon={Check} />Confirm delete</button></form>
  </details>;
}

export function QuickAction({ action, id, extra = {}, label, icon }: { action: unknown; id: string; extra?: Record<string, string>; label: string; icon: 'show' | 'hide' | 'star' | 'up' | 'down' | 'check' }) {
  const I = { show: Eye, hide: EyeOff, star: Star, up: ArrowUp, down: ArrowDown, check: Check }[icon];
  return <form action={act(action)}><input type="hidden" name="id" value={id} />
    {Object.entries(extra).map(([k, v]) => <input type="hidden" name={k} value={v} key={k} />)}
    <button className="admin-button secondary" type="submit" aria-label={label} title={label}><Ic icon={I} /><span className={icon === 'up' || icon === 'down' ? 'sr-only' : ''}>{label}</span></button></form>;
}

export function idOf(record: unknown): string {
  const r = object(record); const v = r.id; return typeof v === 'string' || typeof v === 'number' ? String(v) : '';
}
export { object, value };
