"use client";

import { useEffect, useRef, useState } from "react";
import { Upload, X } from "lucide-react";

type Kind = "image" | "resume" | "attachment";
export async function uploadPortfolioFile(file: File, kind: Kind) {
  const response = await fetch("/portfolio-api/uploads/request-url", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type, kind }),
  });
  const ticket = await response.json();
  if (!response.ok) throw new Error(ticket.error ?? "The upload could not start.");
  const uploaded = await fetch(ticket.uploadURL, {
    method: "PUT", headers: { "Content-Type": file.type }, body: file,
  });
  if (!uploaded.ok) throw new Error("File upload failed. Please retry.");
  const finalized = await fetch("/portfolio-api/uploads/finalize", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ uploadId: ticket.uploadId, token: ticket.token }),
  });
  const result = await finalized.json();
  if (!finalized.ok) throw new Error(result.error ?? "The file could not be verified.");
  return result as { fileUrl: string; fileName: string; mimeType: string; fileSize: number };
}

export function UploadField({ name, kind, label, defaultValue = "", required = false }: {
  name: string; kind: Kind; label: string; defaultValue?: string; required?: boolean;
}) {
  const [value, setValue] = useState(defaultValue);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const form = input.current?.form;
    function preventDuringUpload(event: Event) {
      if (busy) { event.preventDefault(); setError("Please wait for the upload to finish."); }
    }
    form?.addEventListener("submit", preventDuringUpload);
    return () => form?.removeEventListener("submit", preventDuringUpload);
  }, [busy]);
  return <div className="admin-field full">
    <label htmlFor={`upload-${name}`}><Upload size={16} aria-hidden="true" /> {label}</label>
    <input type="hidden" name={name} value={value} />
    <input ref={input} id={`upload-${name}`} type="file" accept={kind === "resume" ? ".pdf" : kind === "image" ? ".jpg,.jpeg,.png,.webp" : ".pdf,.jpg,.jpeg,.png,.webp"}
      disabled={busy} required={required && !value} onChange={async event => {
        const file = event.target.files?.[0];
        if (!file) return;
        setBusy(true); setError("");
        try { setValue((await uploadPortfolioFile(file, kind)).fileUrl); }
        catch (failure) { setError(failure instanceof Error ? failure.message : "Upload failed."); event.target.value = ""; }
        finally { setBusy(false); }
      }} />
    <span className="admin-form-help" aria-live="polite">{busy ? "Uploading and verifying…" : value ? "File verified and ready to save." : kind === "image" ? "JPEG, PNG or WebP, up to 5 MB." : kind === "resume" ? "PDF, up to 10 MB." : "PDF, JPEG, PNG or WebP, up to 10 MB. Attachments are private."}</span>
    {error ? <p role="alert" className="admin-alert">{error}</p> : null}
    {value && kind !== "attachment" ? <a href={value} target="_blank" rel="noreferrer" className="dark-text-link">View current file</a> : null}
  </div>;
}

export function ProjectImagesField({ initial = [] }: {
  initial?: Array<{ imageUrl: string; altText: string }>;
}) {
  const [images, setImages] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const form = input.current?.form;
    const listener = (event: Event) => { if (busy) event.preventDefault(); };
    form?.addEventListener("submit", listener);
    return () => form?.removeEventListener("submit", listener);
  }, [busy]);
  return <div className="admin-field full">
    <label htmlFor="project-images">Project images</label>
    <input type="hidden" name="images" value={JSON.stringify(images)} />
    {images.map((image, index) => <div className="admin-image-row" key={image.imageUrl}>
      <img src={image.imageUrl} alt={image.altText} width={100} height={75} />
      <label>Image description<input required maxLength={300} value={image.altText} onChange={event =>
        setImages(current => current.map((item, position) => position === index ? { ...item, altText: event.target.value } : item))} /></label>
      <button type="button" className="admin-button secondary" aria-label={`Remove image ${index + 1}`} onClick={() => setImages(current => current.filter((_, position) => position !== index))}><X size={16} /></button>
    </div>)}
    <input ref={input} id="project-images" type="file" accept=".jpg,.jpeg,.png,.webp" multiple disabled={busy || images.length >= 12}
      onChange={async event => {
        const files = Array.from(event.target.files ?? []);
        setBusy(true); setError("");
        try {
          for (const file of files.slice(0, 12 - images.length)) {
            const media = await uploadPortfolioFile(file, "image");
            setImages(current => [...current, { imageUrl: media.fileUrl, altText: "" }]);
          }
        } catch (failure) { setError(failure instanceof Error ? failure.message : "Upload failed."); }
        finally { setBusy(false); if (input.current) input.current.value = ""; }
      }} />
    <span className="admin-form-help" aria-live="polite">{busy ? "Uploading and verifying images…" : "Up to 12 real project images, 5 MB each. First image is the cover. Add an accurate description for each."}</span>
    {error ? <p className="admin-alert" role="alert">{error}</p> : null}
  </div>;
}