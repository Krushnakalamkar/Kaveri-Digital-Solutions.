'use client';

import { useSearchParams } from 'next/navigation';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

export function StatusBanner() {
  const params = useSearchParams();
  const error = params?.get('error');
  const saved = params?.get('saved');
  if (error) return <div className="admin-banner is-error" role="alert"><AlertCircle size={16} strokeWidth={1.75} aria-hidden="true" />{error === '1' ? 'That could not be saved. Please check the fields and try again.' : error}</div>;
  if (saved) return <div className="admin-banner is-ok" role="status"><CheckCircle2 size={16} strokeWidth={1.75} aria-hidden="true" />Changes saved.</div>;
  return null;
}
