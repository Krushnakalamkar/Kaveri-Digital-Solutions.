'use client';

import { useState, type FormEvent } from 'react';
import { visitorIntakeRegions } from '@/lib/visitor-intake-regions';

type Match = { token: string; name: string; state: string; date: string; time: string };
type Entry = { name: string; age: number; state: string; date: string; time: string };
type ApiResult = { error?: string; matches?: Match[]; entry?: Entry; success?: boolean };

async function sendRequest(body: Record<string, string | number>) {
  const response = await fetch('/portfolio-api/admin/visitor-intake', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    cache: 'no-store',
  });
  const result = await response.json() as ApiResult;
  if (!response.ok) throw new Error(result.error || 'The request could not be completed.');
  return result;
}

export function VisitorRequests() {
  const [name, setName] = useState('');
  const [matches, setMatches] = useState<Match[]>([]);
  const [selected, setSelected] = useState<{ match: Match; entry: Entry } | null>(null);
  const [correction, setCorrection] = useState({ name: '', age: '', state: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  async function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    setNotice('');
    setSelected(null);
    setMatches([]);
    try {
      const result = await sendRequest({ action: 'search', name });
      setMatches(result.matches ?? []);
      if (!result.matches?.length) setNotice('No exact name match was found. Check the spelling before asking for a minimal distinguishing detail.');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The search could not be completed.');
    } finally {
      setBusy(false);
    }
  }

  async function review(match: Match) {
    setBusy(true);
    setError('');
    setNotice('');
    try {
      const result = await sendRequest({ action: 'inspect', token: match.token });
      if (!result.entry) throw new Error('The entry could not be loaded. Search again.');
      setSelected({ match, entry: result.entry });
      setCorrection({
        name: result.entry.name,
        age: String(result.entry.age || ''),
        state: result.entry.state,
      });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The entry could not be loaded.');
    } finally {
      setBusy(false);
    }
  }

  async function correct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selected) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await sendRequest({
        action: 'correct',
        token: selected.match.token,
        name: correction.name,
        age: Number(correction.age),
        state: correction.state,
      });
      setSelected(null);
      setMatches([]);
      setNotice('Correction completed. Reply to the original email to confirm the request was completed.');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The correction could not be completed.');
    } finally {
      setBusy(false);
    }
  }

  async function removeEntry() {
    if (!selected) return;
    setBusy(true);
    setError('');
    setNotice('');
    try {
      await sendRequest({ action: 'delete', token: selected.match.token });
      setSelected(null);
      setMatches([]);
      setNotice('Deletion completed. Reply to the original email to confirm the request was completed.');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'The entry could not be deleted.');
    } finally {
      setBusy(false);
    }
  }

  return <div className="admin-panel visitor-request-panel">
    <section aria-labelledby="visitor-request-process">
      <h2 id="visitor-request-process">Process a visitor request</h2>
      <ol className="visitor-request-steps">
        <li>Search the exact name the visitor entered in the welcome form. Ask for only the name and the requested correction or deletion.</li>
        <li>Compare the state and submission date/time with the original email. If there are multiple possible entries or the match is uncertain, do not change anything; ask for one detail that distinguishes the entry.</li>
        <li>Open the confirmed entry, make the requested correction or confirm deletion, then reply in the original email thread.</li>
      </ol>
      <p className="admin-form-help">The sheet stays private; matches are read on the server and are not cached. Age is shown only after you open a match. A changed row must be searched and reviewed again.</p>
    </section>

    <form className="admin-form visitor-request-search" onSubmit={search}>
      <div className="admin-field">
        <label htmlFor="visitor-request-name">Exact name from the welcome form</label>
        <input id="visitor-request-name" type="text" value={name} onChange={event => setName(event.target.value)} minLength={2} maxLength={100} required autoComplete="off" />
      </div>
      <div className="admin-form-actions"><button className="admin-button" type="submit" disabled={busy}>Search entries</button></div>
    </form>

    {error ? <p className="admin-banner is-error" role="alert">{error}</p> : null}
    {notice ? <p className="admin-banner is-ok" role="status">{notice}</p> : null}

    {matches.length ? <section className="visitor-request-matches" aria-labelledby="visitor-request-matches-heading">
      <h3 id="visitor-request-matches-heading">Possible matches ({matches.length})</h3>
      <p className="admin-form-help">Use only details already present in the request to distinguish entries. Do not edit a row until the match is certain.</p>
      <div className="admin-table-wrap"><table className="admin-table">
        <thead><tr><th>Name</th><th>State / UT</th><th>Submitted</th><th>Review</th></tr></thead>
        <tbody>{matches.map(match => <tr key={match.token}>
          <td>{match.name}</td><td>{match.state}</td><td>{match.date} · {match.time}</td>
          <td><button type="button" className="admin-button secondary" onClick={() => void review(match)} disabled={busy}>Review entry</button></td>
        </tr>)}</tbody>
      </table></div>
    </section> : null}

    {selected ? <section className="visitor-request-selected" aria-labelledby="visitor-request-selected-heading">
      <h3 id="visitor-request-selected-heading">Review this entry before acting</h3>
      <p className="admin-form-help">Confirm that the name, state, and submission date/time match the visitor’s request. Current age: {selected.entry.age || 'not available'}.</p>
      <form className="admin-form" onSubmit={correct}>
        <div className="admin-form-grid">
          <div className="admin-field"><label htmlFor="visitor-correct-name">Name</label><input id="visitor-correct-name" value={correction.name} onChange={event => setCorrection(current => ({ ...current, name: event.target.value }))} minLength={2} maxLength={100} required /></div>
          <div className="admin-field"><label htmlFor="visitor-correct-age">Age</label><input id="visitor-correct-age" type="number" min={1} max={120} step={1} value={correction.age} onChange={event => setCorrection(current => ({ ...current, age: event.target.value }))} required /></div>
          <div className="admin-field"><label htmlFor="visitor-correct-state">State or Union Territory</label><select id="visitor-correct-state" value={correction.state} onChange={event => setCorrection(current => ({ ...current, state: event.target.value }))} required>
            <option value="" disabled>Select a State or Union Territory</option>
            {visitorIntakeRegions.map(region => <option key={region} value={region}>{region}</option>)}
          </select></div>
        </div>
        <div className="admin-form-actions"><button className="admin-button" type="submit" disabled={busy}>Save correction</button></div>
      </form>
      <details className="admin-confirm visitor-request-delete">
        <summary className="admin-button secondary">Delete this entry</summary>
        <p className="admin-form-help" role="alert">This permanently removes the matched row from the visitor-intake sheet. Confirm only when the visitor requested deletion and the match is certain.</p>
        <button type="button" className="admin-button danger" onClick={() => void removeEntry()} disabled={busy}>Confirm permanent deletion</button>
      </details>
    </section> : null}
  </div>;
}
