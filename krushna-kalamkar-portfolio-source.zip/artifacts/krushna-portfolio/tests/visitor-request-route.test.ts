import { beforeEach, describe, expect, it, vi } from 'vitest';

const { proxy, getAdmin, sameOrigin, secretHash, equalSecrets, isConfiguredOwner } = vi.hoisted(() => ({
  proxy: vi.fn(),
  getAdmin: vi.fn(),
  sameOrigin: vi.fn(),
  isConfiguredOwner: vi.fn(),
  secretHash: vi.fn((value: string) => {
    const hash = [...value].reduce((current, character) => (current * 31 + character.charCodeAt(0)) >>> 0, 7);
    return hash.toString(16).padStart(64, '0');
  }),
  equalSecrets: vi.fn((left: string, right: string) => left === right),
}));

vi.mock('@replit/connectors-sdk', () => ({
  ReplitConnectors: class {
    proxy = proxy;
  },
}));
vi.mock('@/server/auth', () => ({ getAdmin }));
vi.mock('@/server/owner-access', () => ({ isConfiguredOwner }));
vi.mock('@/server/security', () => ({ sameOrigin, secretHash, equalSecrets }));

import { POST } from '../src/app/portfolio-api/admin/visitor-intake/route';

function recordToken(rowNumber: number, row: unknown[]) {
  return `${rowNumber}.${secretHash(`visitor-intake:${rowNumber}:${JSON.stringify(row)}`)}`;
}

function makeRequest(body: unknown) {
  return new Request('http://localhost/portfolio-api/admin/visitor-intake', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      origin: 'http://localhost',
      host: 'localhost',
    },
    body: JSON.stringify(body),
  });
}

async function parse(response: Response) {
  return { status: response.status, body: await response.json() };
}

describe('POST /portfolio-api/admin/visitor-intake', () => {
  beforeEach(() => {
    proxy.mockReset();
    getAdmin.mockResolvedValue({ id: 'owner', email: 'owner@example.com' });
    isConfiguredOwner.mockReturnValue(true);
    sameOrigin.mockReturnValue(true);
  });

  it('denies unauthenticated requests before contacting the private sheet', async () => {
    getAdmin.mockResolvedValueOnce(null);

    const result = await parse(await POST(makeRequest({ action: 'search', name: 'Nina Shah' })));

    expect(result.status).toBe(401);
    expect(proxy).not.toHaveBeenCalled();
  });

  it('denies signed-in administrators who are not the configured owner', async () => {
    isConfiguredOwner.mockReturnValueOnce(false);

    const result = await parse(await POST(makeRequest({ action: 'search', name: 'Nina Shah' })));

    expect(result.status).toBe(403);
    expect(proxy).not.toHaveBeenCalled();
  });

  it('returns only exact-name matches and omits age from the search response', async () => {
    proxy.mockResolvedValueOnce(new Response(JSON.stringify({
      values: [
        ['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35:06 AM IST', true],
        ['Nina Shah', 33, 'Gujarat', '04/03/2025', '03:15:00 PM IST', true],
        ['Nina Sharma', 29, 'Maharashtra', '05/03/2025', '10:15:00 AM IST', true],
      ],
    }), { status: 200 }));

    const response = await POST(makeRequest({ action: 'search', name: 'nina shah' }));
    const result = await parse(response);

    expect(result.status).toBe(200);
    expect(result.body.matches).toHaveLength(2);
    expect(result.body.matches[0]).toMatchObject({
      token: recordToken(1, ['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35:06 AM IST', true]),
      name: 'Nina Shah',
      state: 'Maharashtra',
      date: '02/03/2025',
      time: '12:35:06 AM IST',
    });
    expect(result.body.matches[0]).not.toHaveProperty('age');
    expect(response.headers.get('cache-control')).toBe('no-store, private');
  });

  it('refuses a stale row token without writing changes', async () => {
    proxy.mockResolvedValueOnce(new Response(JSON.stringify({
      values: [['Different person', 29, 'Maharashtra', '02/03/2025', '12:35 AM IST', true]],
    }), { status: 200 }));

    const result = await parse(await POST(makeRequest({
      action: 'correct',
      token: recordToken(1, ['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35 AM IST', true]),
      name: 'Nina Shah',
      age: 30,
      state: 'Maharashtra',
    })));

    expect(result.status).toBe(409);
    expect(proxy).toHaveBeenCalledTimes(1);
  });

  it('corrects requested fields and preserves the original date, time, and consent', async () => {
    proxy
      .mockResolvedValueOnce(new Response(JSON.stringify({
        values: [['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35 AM IST', true]],
      }), { status: 200 }))
      .mockResolvedValueOnce(new Response('{}', { status: 200 }));

    const result = await parse(await POST(makeRequest({
      action: 'correct',
      token: recordToken(1, ['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35 AM IST', true]),
      name: 'Nina Shah',
      age: 30,
      state: 'Gujarat',
    })));

    expect(result.status).toBe(200);
    expect(result.body).toEqual({ success: true });
    expect(proxy).toHaveBeenCalledTimes(2);
    expect(proxy.mock.calls[1]?.[1]).toContain('/values/\'Sheet1\'!A1%3AF1?valueInputOption=RAW');
    expect(JSON.parse(String(proxy.mock.calls[1]?.[2]?.body))).toEqual({
      majorDimension: 'ROWS',
      values: [['Nina Shah', 30, 'Gujarat', '02/03/2025', '12:35 AM IST', true]],
    });
  });

  it('removes the verified row from the Google Sheet', async () => {
    proxy
      .mockResolvedValueOnce(new Response(JSON.stringify({
        values: [['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35 AM IST', true]],
      }), { status: 200 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({
        sheets: [{ properties: { title: 'Sheet1', sheetId: 42 } }],
      }), { status: 200 }))
      .mockResolvedValueOnce(new Response('{}', { status: 200 }));

    const result = await parse(await POST(makeRequest({
      action: 'delete',
      token: recordToken(1, ['Nina Shah', 29, 'Maharashtra', '02/03/2025', '12:35 AM IST', true]),
    })));

    expect(result.status).toBe(200);
    expect(result.body).toEqual({ success: true });
    expect(proxy).toHaveBeenCalledTimes(3);
    expect(proxy.mock.calls[2]?.[1]).toContain('/spreadsheets/1ln90QfuF8V0laWFUnfWcN1Mjpd-BXuYgVD6X7-xJNAg:batchUpdate');
    expect(JSON.parse(String(proxy.mock.calls[2]?.[2]?.body))).toEqual({
      requests: [{
        deleteDimension: {
          range: { sheetId: 42, dimension: 'ROWS', startIndex: 0, endIndex: 1 },
        },
      }],
    });
  });
});
