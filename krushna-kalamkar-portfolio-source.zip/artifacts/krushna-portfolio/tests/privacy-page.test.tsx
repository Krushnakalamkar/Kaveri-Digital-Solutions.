import { createElement } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { cleanup, render, screen, within } from '@testing-library/react';
import PrivacyNoticePage from '../src/app/privacy/page';

vi.mock('next/link', () => ({
  default: ({ href, children, ...props }: { href: string; children: React.ReactNode }) =>
    createElement('a', { ...props, href }, children),
}));

afterEach(cleanup);

describe('GET /privacy', () => {
  it('renders the privacy notice without requiring welcome-form submission', () => {
    render(createElement(PrivacyNoticePage));

    expect(screen.getByRole('heading', { name: 'Privacy notice' })).toBeTruthy();
    expect(screen.queryByTestId('visitor-intake-gate')).toBeNull();
    expect(screen.queryByRole('dialog')).toBeNull();
    expect(screen.queryByRole('form')).toBeNull();
  });

  it('explains collection, purpose, destination, retention, contact, and under-18 handling', () => {
    render(createElement(PrivacyNoticePage));

    const collection = screen.getByRole('heading', { name: 'What we collect and why' }).parentElement;
    expect(collection?.textContent).toContain('name, age, State or Union Territory');
    expect(collection?.textContent).toContain('consent to submit these details');
    expect(collection?.textContent).toContain('visitor insights');

    const destination = screen.getByRole('heading', { name: 'Where your details go' }).parentElement;
    expect(destination?.textContent).toContain('name, age, State or Union Territory, consent, and the date and time of submission');
    expect(destination?.textContent).toContain('connected Google Sheet');
    expect(destination?.textContent).toContain('India local time');
    expect(destination?.textContent).toContain('only a completion marker, not the details you submit');

    const retention = screen.getByRole('heading', { name: 'How long entries are kept' }).parentElement;
    expect(retention?.textContent).toContain('indefinitely unless a deletion request is made');

    const requests = screen.getByRole('heading', { name: 'Correction or deletion requests' }).parentElement;
    const contact = within(requests as HTMLElement).getByRole('link', { name: 'kalamkarkrushna007@gmail.com' });
    expect(contact.getAttribute('href')).toBe('mailto:kalamkarkrushna007@gmail.com');
    expect(requests?.textContent).toContain('correct or delete your visitor-intake entry');

    const minors = screen.getByRole('heading', { name: 'If you are under 18' }).parentElement;
    expect(minors?.textContent).toContain('after a parent or guardian has reviewed the submission');
    expect(minors?.textContent).toContain('consent checkbox confirms this review');
  });
});
