import { createElement } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { VisitorIntake } from '../src/components/site/visitor-intake';

vi.mock('next/link', () => ({
  default: ({ href, children, ...props }: { href: string; children: React.ReactNode }) =>
    createElement('a', { ...props, href }, children),
}));

function renderGate() {
  return render(
    <>
      <main className="site-public">
        <p>Portfolio content</p>
      </main>
      <VisitorIntake />
    </>,
  );
}

function fillValidDetails() {
  fireEvent.change(screen.getByTestId('input-visitor-name'), {
    target: { value: 'Nina Shah' },
  });
  fireEvent.change(screen.getByTestId('input-visitor-age'), {
    target: { value: '29' },
  });
  fireEvent.change(screen.getByTestId('select-visitor-state'), {
    target: { value: 'Maharashtra' },
  });
  fireEvent.click(screen.getByTestId('checkbox-visitor-consent'));
}

function assertGateIsBlocking() {
  expect(screen.getByTestId('visitor-intake-gate')).toBeTruthy();
  expect(document.querySelector('.site-public')?.inert).toBe(true);
  expect(document.documentElement.style.overflow).toBe('hidden');
  expect(document.body.style.overflow).toBe('hidden');
}

describe('VisitorIntake gate', () => {
  beforeEach(() => {
    window.localStorage.clear();
    window.sessionStorage.clear();
    document.documentElement.classList.remove('visitor-intake-complete');
    document.documentElement.style.overflow = '';
    document.body.style.overflow = '';
    document.body.style.overscrollBehavior = '';
    Object.defineProperty(window, 'matchMedia', {
      configurable: true,
      value: vi.fn(() => ({ matches: true })),
    });
    vi.stubGlobal('fetch', vi.fn());
  });

  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('validates required fields and consent before sending a request', async () => {
    const fetchMock = vi.mocked(fetch);
    renderGate();

    await waitFor(() => {
      expect(document.querySelector('.site-public')?.inert).toBe(true);
    });
    assertGateIsBlocking();

    fireEvent.click(screen.getByTestId('button-visitor-submit'));
    expect(await screen.findByText('Please enter at least 2 characters.')).toBeTruthy();
    expect(screen.getByText('Please enter your age.')).toBeTruthy();
    expect(screen.getByText('Choose your State or Union Territory.')).toBeTruthy();
    expect(screen.getByText('Please confirm your consent to continue.')).toBeTruthy();
    expect(fetchMock).not.toHaveBeenCalled();

    fireEvent.change(screen.getByTestId('input-visitor-name'), {
      target: { value: 'Nina Shah' },
    });
    fireEvent.change(screen.getByTestId('input-visitor-age'), {
      target: { value: '29' },
    });
    fireEvent.change(screen.getByTestId('select-visitor-state'), {
      target: { value: 'Maharashtra' },
    });
    fireEvent.click(screen.getByTestId('button-visitor-submit'));

    expect(await screen.findByText('Please confirm your consent to continue.')).toBeTruthy();
    expect(fetchMock).not.toHaveBeenCalled();
    assertGateIsBlocking();
  });

  it('keeps the gate closed after a Sheets API failure and unlocks only after a successful retry', async () => {
    const fetchMock = vi.mocked(fetch);
    let resolveConfirmedSuccess!: (response: Response) => void;
    const confirmedSuccess = new Promise<Response>(resolve => {
      resolveConfirmedSuccess = resolve;
    });
    fetchMock
      .mockResolvedValueOnce(new Response(JSON.stringify({
        error: 'We couldn’t save your details right now. Please try again.',
      }), { status: 502 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({
        error: 'The server did not confirm that your details were saved.',
      }), { status: 200 }))
      .mockReturnValueOnce(confirmedSuccess);

    renderGate();
    fillValidDetails();
    fireEvent.click(screen.getByTestId('button-visitor-submit'));

    expect(await screen.findByTestId('status-visitor-error')).toBeTruthy();
    assertGateIsBlocking();
    expect(window.sessionStorage.getItem('kaveri-visitor-intake-session-complete')).toBeNull();

    fireEvent.click(screen.getByTestId('button-visitor-submit'));
    expect(await screen.findByText('The server did not confirm that your details were saved.')).toBeTruthy();
    assertGateIsBlocking();
    expect(window.sessionStorage.getItem('kaveri-visitor-intake-session-complete')).toBeNull();

    fireEvent.click(screen.getByTestId('button-visitor-submit'));
    await waitFor(() => {
      expect((screen.getByTestId('button-visitor-submit') as HTMLButtonElement).disabled).toBe(true);
    });
    assertGateIsBlocking();
    expect(window.sessionStorage.getItem('kaveri-visitor-intake-session-complete')).toBeNull();

    resolveConfirmedSuccess(new Response(JSON.stringify({ success: true }), { status: 201 }));
    await waitFor(() => expect(screen.queryByTestId('visitor-intake-gate')).toBeNull());

    const publicPage = document.querySelector('.site-public');
    expect(publicPage?.inert).toBe(false);
    expect(document.documentElement.style.overflow).toBe('');
    expect(document.body.style.overflow).toBe('');
    expect(document.body.style.overscrollBehavior).toBe('');
    expect(document.documentElement.classList.contains('visitor-intake-complete')).toBe(true);
    expect(window.sessionStorage.getItem('kaveri-visitor-intake-session-complete')).toBe('true');
    expect(screen.getByText('Portfolio content')).toBeTruthy();
    expect(fetchMock).toHaveBeenCalledTimes(3);
    const submittedBodies = fetchMock.mock.calls.map(([, options]) =>
      JSON.parse(String(options?.body)) as { submissionId: string },
    );
    expect(new Set(submittedBodies.map(body => body.submissionId)).size).toBe(1);
  });

  it('keeps the gate dismissed in one tab session and shows it again in a fresh session', async () => {
    const storageKey = 'kaveri-visitor-intake-session-complete';
    window.sessionStorage.setItem(storageKey, 'true');

    const firstRender = renderGate();
    await waitFor(() => expect(screen.queryByTestId('visitor-intake-gate')).toBeNull());

    document.documentElement.classList.remove('visitor-intake-complete');
    firstRender.unmount();
    renderGate();
    await waitFor(() => expect(screen.queryByTestId('visitor-intake-gate')).toBeNull());

    window.sessionStorage.clear();
    document.documentElement.classList.remove('visitor-intake-complete');
    cleanup();
    renderGate();
    await waitFor(() => expect(screen.getByTestId('visitor-intake-gate')).toBeTruthy());
    assertGateIsBlocking();
  });

  it('keeps visitors locked and offers a retry when the network request fails', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockRejectedValueOnce(new TypeError('offline'));

    renderGate();
    fillValidDetails();
    fireEvent.click(screen.getByTestId('button-visitor-submit'));

    expect(await screen.findByTestId('status-visitor-error')).toBeTruthy();
    expect(screen.getByTestId('status-visitor-error').textContent).toContain('offline');
    assertGateIsBlocking();
    expect(window.sessionStorage.getItem('kaveri-visitor-intake-session-complete')).toBeNull();
  });

  it('uses a fresh retry ID when visitor details change after a failed request', async () => {
    const fetchMock = vi.mocked(fetch);
    fetchMock.mockResolvedValue(new Response(JSON.stringify({
      error: 'We couldn’t save your details right now. Please try again.',
    }), { status: 502 }));

    renderGate();
    fillValidDetails();
    fireEvent.click(screen.getByTestId('button-visitor-submit'));
    await screen.findByTestId('status-visitor-error');

    const firstBody = JSON.parse(String(fetchMock.mock.calls[0]?.[1]?.body)) as { submissionId: string };
    fireEvent.change(screen.getByTestId('input-visitor-name'), {
      target: { value: 'Nina Rao' },
    });
    fireEvent.click(screen.getByTestId('button-visitor-submit'));
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));

    const secondBody = JSON.parse(String(fetchMock.mock.calls[1]?.[1]?.body)) as { submissionId: string };
    expect(secondBody.submissionId).not.toBe(firstBody.submissionId);
    assertGateIsBlocking();
  });

  it('keeps the site unlocked across client navigation when browser storage is unavailable', async () => {
    vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
      throw new Error('storage unavailable');
    });
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('storage unavailable');
    });
    vi.mocked(fetch).mockResolvedValueOnce(new Response(JSON.stringify({ success: true }), { status: 201 }));

    renderGate();
    fillValidDetails();
    fireEvent.click(screen.getByTestId('button-visitor-submit'));

    await waitFor(() => expect(screen.queryByTestId('visitor-intake-gate')).toBeNull());
    expect(document.documentElement.classList.contains('visitor-intake-complete')).toBe(true);

    cleanup();
    renderGate();
    await waitFor(() => expect(screen.queryByTestId('visitor-intake-gate')).toBeNull());
    expect(document.querySelector('.site-public')?.inert).not.toBe(true);
    expect(document.documentElement.style.overflow).toBe('');
    expect(document.body.style.overflow).toBe('');
  });
});
