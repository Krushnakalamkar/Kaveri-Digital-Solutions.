import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const { proxy, sameOrigin, clientIdentifier, consumeLimit } = vi.hoisted(() => ({
  proxy: vi.fn(),
  sameOrigin: vi.fn(),
  clientIdentifier: vi.fn(),
  consumeLimit: vi.fn(),
}));

vi.mock('@replit/connectors-sdk', () => ({
  ReplitConnectors: class {
    proxy = proxy;
  },
}));

vi.mock('@/server/security', () => ({
  sameOrigin,
  clientIdentifier,
  consumeLimit,
}));

import { POST } from '../src/app/portfolio-api/visitor-intake/route';

const validSubmission = {
  name: '  Nina Shah  ',
  age: 29,
  state: 'Maharashtra',
  consent: true,
};

function makeRequest(body: unknown) {
  return new Request('http://localhost/portfolio-api/visitor-intake', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      origin: 'http://localhost',
      host: 'localhost',
    },
    body: JSON.stringify(body),
  });
}

async function readResponse(response: Response) {
  return {
    status: response.status,
    body: await response.json(),
  };
}

describe('POST /portfolio-api/visitor-intake', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2025-03-01T19:05:06.000Z'));
    proxy.mockReset();
    proxy.mockResolvedValue(new Response('{}', { status: 200 }));
    sameOrigin.mockReturnValue(true);
    clientIdentifier.mockResolvedValue('test-client');
    consumeLimit.mockResolvedValue(true);
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('rejects invalid fields and missing consent without contacting Sheets', async () => {
    const invalidFields = await readResponse(await POST(makeRequest({
      name: 'N',
      age: 0,
      state: 'Atlantis',
      consent: false,
    })));
    const missingConsent = await readResponse(await POST(makeRequest({
      ...validSubmission,
      consent: false,
    })));

    expect(invalidFields.status).toBe(400);
    expect(invalidFields.body).toEqual({
      error: 'Check your name, age, state, and consent before continuing.',
    });
    expect(missingConsent.status).toBe(400);
    expect(proxy).not.toHaveBeenCalled();
  });

  it('appends name, age, State/UT, India-local date, time, and consent in sheet columns A–F using a mocked connector', async () => {
    const response = await POST(makeRequest(validSubmission));

    expect(response.status).toBe(201);
    expect(await response.json()).toEqual({ success: true });
    expect(proxy).toHaveBeenCalledTimes(1);

    const [service, endpoint, options] = proxy.mock.calls[0] as [
      string,
      string,
      RequestInit,
    ];
    expect(service).toBe('google-sheet');
    expect(endpoint).toBe(
      "/v4/spreadsheets/1ln90QfuF8V0laWFUnfWcN1Mjpd-BXuYgVD6X7-xJNAg/values/'Sheet1'!A%3AF:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS",
    );
    expect(options.method).toBe('POST');
    expect(JSON.parse(String(options.body))).toEqual({
      majorDimension: 'ROWS',
      // Sheet columns A–F: name, age, State/UT, date, time, consent.
      values: [[
        'Nina Shah',
        29,
        'Maharashtra',
        '02/03/2025',
        '12:35:06 AM IST',
        true,
      ]],
    });
  });

  it('returns an error when the Sheets API rejects the append', async () => {
    proxy.mockResolvedValueOnce(new Response('unavailable', { status: 503 }));

    const result = await readResponse(await POST(makeRequest(validSubmission)));

    expect(result.status).toBe(502);
    expect(result.body).toEqual({
      error: 'We couldn’t save your details right now. Please try again.',
    });
  });

  it('returns an error when the connector request fails on the network', async () => {
    proxy.mockRejectedValueOnce(new TypeError('network unavailable'));

    const result = await readResponse(await POST(makeRequest(validSubmission)));

    expect(result.status).toBe(503);
    expect(result.body).toEqual({
      error: 'We couldn’t save your details right now. Please try again.',
    });
  });
});
