import { describe, expect, it } from 'vitest';
import { isConfiguredOwner } from '../src/server/owner-access';

describe('configured owner access', () => {
  it('matches the configured owner email without case or surrounding-space differences', () => {
    expect(isConfiguredOwner({ email: 'Owner@Example.com' }, ' owner@example.com ')).toBe(true);
  });

  it('denies other accounts and fails closed when the owner is not configured', () => {
    expect(isConfiguredOwner({ email: 'other@example.com' }, 'owner@example.com')).toBe(false);
    expect(isConfiguredOwner({ email: 'owner@example.com' }, '')).toBe(false);
    expect(isConfiguredOwner(null, 'owner@example.com')).toBe(false);
  });
});
